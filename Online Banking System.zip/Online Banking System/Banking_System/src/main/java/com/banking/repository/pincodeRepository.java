package com.banking.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.banking.entity.Transaction_Details;
import com.banking.entity.pincode;

public interface pincodeRepository  extends JpaRepository<pincode,Long>{

    
    @Query("SELECT a FROM pincode a WHERE a.pincode = :pincode")
       public pincode findBypincode(@Param("pincode") long pincode);
    
    
    
    
    
}

