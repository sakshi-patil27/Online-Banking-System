package com.banking.Service;

import java.security.NoSuchAlgorithmException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Collectors;

import org.hibernate.internal.build.AllowSysOut;
import org.json.JSONObject;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.banking.config.ModelMapperConfig;
import com.banking.dto.Account_DetailsDto;
import com.banking.dto.CustomerDto;
import com.banking.dto.CustomerTransactionSummary;
import com.banking.dto.getByAccountTypeDto;
import com.banking.entity.Account_Details;
import com.banking.entity.Bank_Staff;
import com.banking.entity.CheckBook;
import com.banking.entity.Customer;
import com.banking.entity.Transaction_Details;
import com.banking.entity.User_Master;
import com.banking.entity.pincode;
import com.banking.exception.ResourceNotFoundException;
import com.banking.repository.AccountDetailsRepository;
import com.banking.repository.BankStaffRepo;
import com.banking.repository.BankUserRepo;
import com.banking.repository.BankdaoRepo;
import com.banking.repository.CheckBookRepo;
import com.banking.repository.TransRepo;
import com.banking.repository.pincodeRepository;
import com.banking.response.ActualReqResp;
import com.banking.response.CustomResponse;
import com.banking.response.DateBetween;
import com.banking.response.PlainResponce;
import com.banking.response.ProfileResponse;
import com.banking.response.ResponeAccountnum;
import com.banking.response.ResponseForBalance;
import com.banking.response.ResponseForCheckBook;
import com.banking.response.ResponseForEncryAndHash;
import com.banking.response.ResponseForToken;
import com.banking.response.ResponseModel;
import com.banking.response.Responsemodel1;
import com.banking.security.ClientEncrypt;
import com.banking.security.CryptoUtils;
import com.banking.security.TokenServices;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@Service
public class BankService {
	@Autowired
	private BankdaoRepo bankrepo;
	@Autowired
	private BankUserRepo bankuser;

	@Autowired
	private AccountDetailsRepository accountdetailrepository;

	@Autowired
	private BankStaffRepo bankstaffrepo;
	@Autowired
	private TransRepo transrepo;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private pincodeRepository pinrepo;

	@Autowired
	private ClientEncrypt clientencry;

	@Autowired
	private TokenServices tokenservice;
   
	@Autowired
	private CryptoUtils cryptoutils;
	

    @Autowired
    private CheckBookRepo checkBookRepo;

	// Add Customer
	public ResponseEntity addAccount(String authorization, ActualReqResp req) throws Exception {
		ResponseModel response;
		if (validateToken(authorization)) {
			String decry = clientencry.decrypt(req.getEncrypt());
			String hash = clientencry.createSHAHash(decry);
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode jsonNode = objectMapper.readTree(decry);
			long staff_id = jsonNode.get("staff_id").asLong();
			Bank_Staff bs1 = bankstaffrepo.findById(staff_id).get();
			if (req.getHash().equals(hash)) {
				if (bs1 != null) {
					long millis = System.currentTimeMillis();
					java.sql.Date date = new java.sql.Date(millis);
					Customer customer = new Customer();
					String fname = jsonNode.get("fname").asText();
					String lname = jsonNode.get("lname").asText();
					String email = jsonNode.get("email").asText();
					String address = jsonNode.get("address").asText();
					long phoneNo = jsonNode.get("phone_no").asLong();
					String password = jsonNode.get("password").asText();
					String pancard = jsonNode.get("pancard").asText();
					int pincode = jsonNode.get("pincode").asInt();
					long staffId = jsonNode.get("staff_id").asLong();
					String dobString = jsonNode.get("dob").asText();
					long dobMillis = Long.parseLong(dobString);
					Date dob = new Date(dobMillis);

					// Set dob in the customer object
					customer.setDob(dob);
					customer.setFname(fname);
					customer.setLname(lname);
					customer.setDob((Date) dob);
					customer.setEmail(email);
					customer.setAddress(address);
					customer.setPhone_no(phoneNo);
					customer.setPassword(password);
					customer.setPancard(pancard);
					customer.setPincode(pincode);
					customer.setCreated_on(date);
					String fname1 = bs1.getFname() + bs1.getLname();
					customer.setCreated_by(fname1);

					Customer cu = bankrepo.save(customer);
					User_Master user = new User_Master(cu.getEmail(), cu.getPassword(), "Customer", cu);
					bankuser.save(user);

					response = new ResponseModel("Registration is successful", "200");
					String fileName = "AddCustomer";
					MyTools.createLog("/addcustomer", decry, objectMapper.writeValueAsString(response),
							objectMapper.writeValueAsString(req),
							objectMapper.writeValueAsString(clientencry.encryptandhashforResponseModel(response)),
							fileName);
				} else {

					response = new ResponseModel("Error:please enter valid staff id", "201");
				}
			} else {
				response = new ResponseModel("Error:Hash authintication Fail", "404");
			}
		} else {
			response = new ResponseModel("Error:Authorization fail", "404");
		}

		if (response.getStatus().equals(200)) {
			return ResponseEntity.status(HttpStatus.OK).body(clientencry.encryptandhashforResponseModel(response));
		} else {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(clientencry.encryptandhashforResponseModel(response));
		}
	}

	public ResponseEntity login(ActualReqResp req) throws Exception {
		String decry = clientencry.decrypt(req.getEncrypt());
		String hash = clientencry.createSHAHash(decry);
		ResponseForToken response;
		if (req.getHash().equals(hash)) {
			ObjectMapper objectmapper = new ObjectMapper();
			User_Master um = objectmapper.readValue(decry, User_Master.class);
			String uname = um.getUsername();
			User_Master um1 = bankuser.findByUsernameAndPassword(um.getUsername(), um.getPassword());
			if (um1 != null) {
				String token = tokenservice.generateToken(uname);
				um1.setToken(token);
				bankuser.save(um1);
				response = new ResponseForToken("Authorization Successful", token, "200");
				String fileName = "Login";
				MyTools.createLog("/login", decry, objectmapper.writeValueAsString(response),
						objectmapper.writeValueAsString(req),
						objectmapper.writeValueAsString(clientencry.encryptandhashforResponseModelForToken(response)),
						fileName);
			} else {
				response = new ResponseForToken("Error: Please enter the valid username and password", " ", "404");
			}
		} else {
			response = new ResponseForToken("Error:Hash authintication Fail", " ", "404");
		}
		if (response.getStatus().equals(200)) {
			return ResponseEntity.status(HttpStatus.OK)
					.body(clientencry.encryptandhashforResponseModelForToken(response));
		} else {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(clientencry.encryptandhashforResponseModelForToken(response));
		}

	}

	public ResponseEntity deposit(ActualReqResp req, String authorization) throws Exception {
		ResponseModel response;
		if (validateToken(authorization)) {
			String decry = clientencry.decrypt(req.getEncrypt());
			System.out.println(decry);
			String hash = clientencry.createSHAHash(decry);
			if (req.getHash().equals(hash)) {
				ObjectMapper objectmapper = new ObjectMapper();
				JsonNode jsonnode = objectmapper.readTree(decry);
				long cus_id = jsonnode.get("customer_id").asLong();
				System.out.println(cus_id);
				Transaction_Details tran = new Transaction_Details();
				Customer cu = bankrepo.findById(cus_id).get();
				System.out.println(cu);
				tran.setAccountnumber(jsonnode.get("accountnumber").asLong());
				tran.setAmount(jsonnode.get("amount").asLong());

				String fname = cu.getFname() + cu.getLname();
				double amount = tran.getAmount();
				long accno = tran.getAccountnumber();
				Account_Details ad = accountdetailrepository.findByAccountnumber(accno);
				double balance = ad.getBalance();
				if (cu.getStatus().equals("y")) {
					if (cu != null) {
						if (ad != null) {
							balance = balance + amount;
							System.out.println("balance" + balance);
							ad.setBalance(balance);
							ad.setModified_by(fname);
							Long id = transrepo.count() + 1;
							Long sid = Long.parseLong("1" + String.format("%03d", id));
							tran.setTransaction_id(sid);
							tran.setCustomer(cu);
							tran.setCreated_by(fname);
							tran.setTransactiontype("deposit");
							long millis = System.currentTimeMillis();
							java.sql.Date date = new java.sql.Date(millis);
							tran.setTransactiondate(date);
							tran.setCreated_on(date);
							ad.setModified_on(date);
							transrepo.save(tran);
							response = new ResponseModel("Successfully added the transaction details", "200");
							String fileName = "Deposit";
							MyTools.createLog("/transaction/deposit", decry, objectmapper.writeValueAsString(response),
									objectmapper.writeValueAsString(req), objectmapper.writeValueAsString(
											clientencry.encryptandhashforResponseModel(response)),
									fileName);
						} else {
							response = new ResponseModel("please enter the valid account number", "404");
						}
					} else {
						response = new ResponseModel("please enter the transaction of valid customer", "404");
					}
				} else {
					response = new ResponseModel("please enter the transaction of valid ", "404");
				}
			} else {
				response = new ResponseModel("Error:Hash authintication Fail", "404");
			}
		} else {
			response = new ResponseModel("Error:Authorization fail", "404");
		}
		if (response.getStatus().equals(200)) {
			return ResponseEntity.status(HttpStatus.OK).body(clientencry.encryptandhashforResponseModel(response));
		} else {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(clientencry.encryptandhashforResponseModel(response));
		}
	}

	public ResponseEntity withdrawal(ActualReqResp req, String authorization) throws Exception {
		ResponseModel response;
		if (validateToken(authorization)) {
			String decry = clientencry.decrypt(req.getEncrypt());
			String hash = clientencry.createSHAHash(decry);
			if (req.getHash().equals(hash)) {
				ObjectMapper objectmapper = new ObjectMapper();
				JsonNode jsonnode = objectmapper.readTree(decry);
				System.out.println(jsonnode);
				long cus_id = jsonnode.get("customer_id").asLong();
				Transaction_Details tran = new Transaction_Details();
				tran.setAccountnumber(jsonnode.get("accountnumber").asLong());
				tran.setAmount(jsonnode.get("amount").asLong());
				Customer cu = bankrepo.findById(cus_id).get();
				System.out.println(cu);
				String fname = cu.getFname() + cu.getLname();
				double amount = tran.getAmount();
				long accno = tran.getAccountnumber();
				Account_Details ad = accountdetailrepository.findByAccountnumber(accno);
				double balance = ad.getBalance();
				if (cu != null) {
					if (ad != null) {
						if (amount <= balance) {
							balance = balance - amount;
							ad.setBalance(balance);
							ad.setModified_by(fname);

							accountdetailrepository.save(ad);
							Long id = transrepo.count() + 1;
							Long sid = Long.parseLong("1" + String.format("%03d", id));
							tran.setTransaction_id(sid);
							tran.setCustomer(cu);
							tran.setCreated_by(fname);
							tran.setTransactiontype("withdrawal");
							long millis = System.currentTimeMillis();
							java.sql.Date date = new java.sql.Date(millis);
							tran.setTransactiondate(date);
							tran.setCreated_on(date);
							ad.setModified_on(date);
							transrepo.save(tran);
							response = new ResponseModel("Successfully added the transaction details", "200");
							String fileName = "Withdrawal";
							MyTools.createLog("/transaction/withdrawal", decry,
									objectmapper.writeValueAsString(response), objectmapper.writeValueAsString(req),
									objectmapper.writeValueAsString(
											clientencry.encryptandhashforResponseModel(response)),
									fileName);
						} else {
							response = new ResponseModel("your amount is grater than your balance", "200");
						}
					} else {
						response = new ResponseModel("Please enter a valid account number", "200");
					}
				} else {
					response = new ResponseModel("please enter the transaction of valid customer", "200");
				}
			} else {
				response = new ResponseModel("Error:Hash authintication Fail", "404");
			}
		} else {
			response = new ResponseModel("Error:Authorization fail", "404");
		}
		if (response.getStatus().equals(200)) {
			return ResponseEntity.status(HttpStatus.OK).body(clientencry.encryptandhashforResponseModel(response));
		} else {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(clientencry.encryptandhashforResponseModel(response));
		}
	}

	public Boolean validateToken(String authorizationHeader) {
		String token = authorizationHeader.substring("Bearer".length()).trim();
		boolean flag = false;
		User_Master um = bankuser.findByToken(token);
		if (um != null) {
			String token1 = um.getToken();
			if (token1.equals(token)) {
				System.out.println("the validation complete");
				flag = true;
			} else {
				flag = false;
			}
		} else {
			flag = false;
		}
		return flag;
	}

	@Transactional
	public void addInterestToSavingsAccount() {
		List<Account_Details> savingaccounts = accountdetailrepository.findByAccounttype("Saving");
		for (Account_Details ad : savingaccounts) {
			double newBalance = ad.getBalance() * 1.0025;
			ad.setBalance(newBalance);
			accountdetailrepository.save(ad);
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	// Get account details from customer Id_HD
	    public ActualReqResp getAccountDetailsbyId(ActualReqResp body, String authorizationHeader) throws NoSuchAlgorithmException, JsonProcessingException {
	        String plainJsonReq = cryptoutils.decrypt(body.getEncrypt());
	        String hash1 = cryptoutils.getCheckSumValue(plainJsonReq,"SHA256");
	        ObjectMapper objectMapper = new ObjectMapper();
	        CustomerDto custdetails = objectMapper.readValue(plainJsonReq, CustomerDto.class);
	        if (hash1.equals(body.getHash())) {// Validate hash
	            boolean b = validateToken(authorizationHeader);
	            if (b = true) {// Validate token
	                String status= "y";
	                Customer customer = bankrepo.findByidAndStatus(custdetails.getCustomer_id(),status);
	                if (customer == null) {// validate customer id
	                    Responsemodel1 res = new Responsemodel1("Invalid Customer Id",null,"201");
	                    String encData = cryptoutils.encrypt(objectMapper.writeValueAsString(res));
	                    String reqHash = cryptoutils.getCheckSumValue(encData,"SHA256");
	                    return new ActualReqResp(encData,reqHash);
	                } 
	                else {// validate customer id
	                    List<Account_Details> data = accountdetailrepository.findByCustomerId(custdetails.getCustomer_id());
	                    List<Account_DetailsDto> list= data.stream().map(data1 -> (modelMapper).map(data1, Account_DetailsDto.class))
	                        .collect(Collectors.toList());
	                    Responsemodel1 plainJsonres = new Responsemodel1("Account details fetched succesfully",list,"200");
	                    String encData = cryptoutils.encrypt(objectMapper.writeValueAsString(plainJsonres));
	                    String reqHash = cryptoutils.getCheckSumValue(encData,"SHA256");
	                    ActualReqResp actualRes= new ActualReqResp(encData,reqHash);
	                    String fileName = "getAccountDetailsbyId";
	                    MyTools.createLog("/getAccountsById", plainJsonReq,objectMapper.writeValueAsString(plainJsonres) , objectMapper.writeValueAsString(body),
	                            objectMapper.writeValueAsString(actualRes), fileName);
	                    return actualRes;
	                }
	            } 
	            else {// Validate token
	                Responsemodel1 res = new Responsemodel1("Invalid Token",null,"201");
	                String encData = cryptoutils.encrypt(objectMapper.writeValueAsString(res));
	                String reqHash = cryptoutils.getCheckSumValue(encData,"SHA256");
	                return new ActualReqResp(encData,reqHash);
	            }
	        }    
	        else {// Validate hash
	            Responsemodel1 res = new Responsemodel1("Invalid Hash",null,"201");
	            String encData = cryptoutils.encrypt(objectMapper.writeValueAsString(res));
	            String reqHash = cryptoutils.getCheckSumValue(encData,"SHA256");
	            return new ActualReqResp(encData,reqHash);
	        }
	    }
	    
	    
	    
	    
	 // Get Balance from Account number_HD
		public ActualReqResp getBalancebyAccountnumber(ActualReqResp body,String authorizationHeader) throws NoSuchAlgorithmException, JsonMappingException, JsonProcessingException {
			String plainJsonReq = cryptoutils.decrypt(body.getEncrypt());
			String hash1 = cryptoutils.getCheckSumValue(plainJsonReq,"SHA256");
			System.out.println(hash1);
			ObjectMapper objectMapper = new ObjectMapper();
			Account_Details accdetails = objectMapper.readValue(plainJsonReq, Account_Details.class);
			if (hash1.equals(body.getHash())) {//Validate Hash
				boolean b = validateToken(authorizationHeader);
				if(b = true){//Validate token
					Account_Details data = accountdetailrepository.findByaccountnumber(accdetails.getAccountnumber());
					if (data == null) {//validate Account number
						ResponseForBalance res = new ResponseForBalance("Invalid Account Number", 0,"201");
						String encData = cryptoutils.encrypt(objectMapper.writeValueAsString(res));
						String reqHash = cryptoutils.getCheckSumValue(encData,"SHA256");
						return new ActualReqResp(encData,reqHash);
					} 
					else {//validate Account number
						double balance = data.getBalance();
						ResponseForBalance plainJsonres = new ResponseForBalance("Balance fetched succesfully",balance,"200");
						String encData = cryptoutils.encrypt(objectMapper.writeValueAsString(plainJsonres));
						String reqHash = cryptoutils.getCheckSumValue(encData,"SHA256");
						ActualReqResp actualRes =new ActualReqResp(encData,reqHash);
						String fileName = "getbalancebyaccnumber";
						MyTools.createLog("/getbalancebyaccnumber", plainJsonReq,objectMapper.writeValueAsString(plainJsonres) , objectMapper.writeValueAsString(body),
								objectMapper.writeValueAsString(actualRes), fileName);
						return actualRes;
					}
				}
				else {//Validate token
					ResponseForBalance res = new ResponseForBalance("Invalid Token", 0,"201");
					String encData = cryptoutils.encrypt(objectMapper.writeValueAsString(res));
					String reqHash = cryptoutils.getCheckSumValue(encData,"SHA256");
					return new ActualReqResp(encData,reqHash);
				}
			}
			else {//Validate Hash
				ResponseForBalance res = new ResponseForBalance("Invalid Hash", 0,"201");
				String encData = cryptoutils.encrypt(objectMapper.writeValueAsString(res));
				String reqHash = cryptoutils.getCheckSumValue(encData,"SHA256");
				return new ActualReqResp(encData,reqHash);
			}
		}

		// Get Balance from Customer Id and Account type_HD
		public ActualReqResp getBalancebyAccountType(ActualReqResp body,String authorizationHeader) throws NoSuchAlgorithmException, JsonMappingException, JsonProcessingException {
			String plainJsonReq = cryptoutils.decrypt(body.getEncrypt());
			String hash1 = cryptoutils.getCheckSumValue(plainJsonReq,"SHA256");
			ObjectMapper objectMapper = new ObjectMapper();
			getByAccountTypeDto reqdata = objectMapper.readValue(plainJsonReq, getByAccountTypeDto.class);
			boolean b = validateToken(authorizationHeader);
			if (hash1.equals(body.getHash())) {//Validate Hash
				if(b = true) {//Validate token
					String status= "y";//Validate status of account
					Customer customer = bankrepo.findByidAndStatus(reqdata.getCustomer_id(),status);
					if (customer == null) {//validate customer id
						ResponseForBalance res = new ResponseForBalance("Invalid customer ID", 0,"201");
						String encData = cryptoutils.encrypt(objectMapper.writeValueAsString(res));
						String reqHash = cryptoutils.getCheckSumValue(encData,"SHA256");
						return new ActualReqResp(encData,reqHash);
					} 
					else {//validate customer id
						Account_Details data = accountdetailrepository.findByCustidAndAccType(reqdata.getCustomer_id(), reqdata.getAccounttype());
						double balance = data.getBalance();
						ResponseForBalance plainJsonres = new ResponseForBalance("Balance fetched succesfully",balance,"200");
						String encData = cryptoutils.encrypt(objectMapper.writeValueAsString(plainJsonres));
						String reqHash = cryptoutils.getCheckSumValue(encData,"SHA256");
						ActualReqResp actualRes =new ActualReqResp(encData,reqHash);
						String fileName = "getBalancebyCustidAndAcctype";
						MyTools.createLog("/getbalance", plainJsonReq,objectMapper.writeValueAsString(plainJsonres) , objectMapper.writeValueAsString(body),
								objectMapper.writeValueAsString(actualRes), fileName);
						return actualRes;
					}		
				}
				else {//Validate token
					ResponseForBalance res = new ResponseForBalance("Invalid Token", 0,"201");
					String encData = cryptoutils.encrypt(objectMapper.writeValueAsString(res));
					String reqHash = cryptoutils.getCheckSumValue(encData,"SHA256");
					return new ActualReqResp(encData,reqHash);
				}
			}	
			else {//Validate Hash
				ResponseForBalance res = new ResponseForBalance("Invalid Hash", 0,"201");
				String encData = cryptoutils.encrypt(objectMapper.writeValueAsString(res));
				String reqHash = cryptoutils.getCheckSumValue(encData,"SHA256");
				return new ActualReqResp(encData,reqHash);
			}
		}
	    
	    
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

		//Get the customer profile by id
		    
		    public ActualReqResp getCustomerWithAccountDetails(ActualReqResp body ,String authorization) throws Exception {
		        //token validation
		        if (validateToken(authorization)) {
		            
		            //decrypt the data from payloads and generate hash
		            String decry = CryptoUtils.decrypt(body.getEncrypt());
		            String hash1 = CryptoUtils.getCheckSumValue(decry,"SHA256");
		            ObjectMapper objMapper = new ObjectMapper();
		            Customer customer1 = objMapper.readValue(decry, Customer.class);
		            long customer_id= customer1.getCustomer_id();
		            
		            
		            //compare the hash generated and provided hash from the body
		            if (hash1.equals(body.getHash())) {
		           Optional<Customer> customerOptional = bankrepo.findById(customer_id);
		           
		           if (!customerOptional.isPresent()) {

		               ProfileResponse profileresponse = new ProfileResponse(null,"201","Customer not found with id : " + customer_id);
		                ObjectMapper obj1 = new ObjectMapper();
		                String jsonData1 = obj1.writeValueAsString(profileresponse);
		                String encrypt = CryptoUtils.encrypt(jsonData1);
		                String hash2 = CryptoUtils.getCheckSumValue(jsonData1,"SHA256");
		                ActualReqResp responce1 = new ActualReqResp(encrypt,hash2 );
		                return responce1;

		           }
		           
		        Customer customer = customerOptional.get();
		        if(customer.getStatus().equals("y")) {
		            
		        List<Account_Details> account_details = accountdetailrepository.findByCustomerId(customer_id);
		        CustomerDto customerDto = new CustomerDto();
		        customerDto.setCustomer_id(customer.getCustomer_id());
		        customerDto.setFname(customer.getFname());
		        customerDto.setLname(customer.getLname());
		        customerDto.setDob(customer.getDob());
		        customerDto.setEmail(customer.getEmail());
		        customerDto.setAddress(customer.getAddress());
		        customerDto.setPhone_no(customer.getPhone_no());
		        customerDto.setPincode(customer.getPincode());
		        customerDto.setPancard(customer.getPancard());

		        customerDto.setAccountDetails(account_details.stream().map(ad -> {

		            Account_DetailsDto adDto = new Account_DetailsDto();
		            adDto.setAccid(ad.getAccid());
		            adDto.setAccountnumber(ad.getAccountnumber());
		            adDto.setAccounttype(ad.getAccounttype());
		            adDto.setBalance(ad.getBalance());
		            adDto.setCreated_on(ad.getCreated_on());
		            adDto.setIFSC(ad.getIFSC());
		            adDto.setBranch_name(ad.getBranch_name());
		            return adDto;
		        }).collect(Collectors.toList()));

		    

		        String message = "Successfully retrived the profile";
		        
		        ProfileResponse profileresponse= new ProfileResponse(customerDto,"200",message);
		        ObjectMapper obj1 = new ObjectMapper();
		        System.out.println(obj1);
		        String jsonData = obj1.writeValueAsString(profileresponse);
		        System.out.println(jsonData);
		        String encrypt = CryptoUtils.encrypt(jsonData);
		        System.out.println(encrypt);
		        String hash2 = CryptoUtils.getCheckSumValue(jsonData,"SHA256");
		        System.out.println(hash2);
		        
		        ActualReqResp response = new ActualReqResp(encrypt,hash2);
		        
		        //Apilog
		        String fileName = "getcustomerbyId";
		        MyTools.createLog("/getcustomerbyId", decry, jsonData, obj1.writeValueAsString(body),
		                obj1.writeValueAsString(response), fileName);
		        
		        return response;
		            }
		        return null;
		        
		        
		        }
		            else {
		                ProfileResponse profileresponse = new ProfileResponse(null,"201","Invalid Hash...!");
		                ObjectMapper obj1 = new ObjectMapper();
		                String jsonData1 = obj1.writeValueAsString(profileresponse);
		                String encrypt = CryptoUtils.encrypt(jsonData1);
		                String hash2 = CryptoUtils.getCheckSumValue(jsonData1,"SHA256");
		                ActualReqResp responce1 = new ActualReqResp(encrypt,hash2 );
		                
		                return responce1;
		            }
		        }
		        
		        else {
		            ProfileResponse profileresponse = new ProfileResponse(null,"201","Invalid Token...!");
		            ObjectMapper obj1 = new ObjectMapper();
		            String jsonData = obj1.writeValueAsString(profileresponse);
		            String encrypt = CryptoUtils.encrypt(jsonData);
		            String hash2 = CryptoUtils.getCheckSumValue(jsonData,"SHA256");
		            ActualReqResp responce2 = new ActualReqResp(encrypt,hash2);
		            
		            return responce2;
		        }
		    }


		    
		    
		    
		    
		    
		    
		    
		    
		    
		    
		    //Transaction get by Id

		    public ActualReqResp transaction_get_by_id(String autherizationHeader, ActualReqResp body) throws Exception {
		        ActualReqResp respmodel;
		        
		        String plainJsonReq = cryptoutils.decrypt(body.getEncrypt());
		        String hash1 = cryptoutils.createSHAHash(plainJsonReq);
		        ObjectMapper objectMapper = new ObjectMapper();
		        Customer custdetails = objectMapper.readValue(plainJsonReq, Customer.class);

		        if (hash1.equals(body.getHash())) {
		            if (validateToken(autherizationHeader)) {

		                String status = "y";

		                Customer customer = bankrepo.findById(custdetails.getCustomer_id()).get();
		                if (!customer.getStatus().equals(status)) {
		                    return null;
		                }
		                if (customer == null) {
		                    return null;
		                }

		                List<Transaction_Details> transactions = customer.getTransaction_details();
		                if (transactions.isEmpty()) {
		                    CustomResponse custresp = new CustomResponse("201", "No trasactions found for given customer id",
		                            null);
		                    String encrypted_String = CryptoUtils.encrypt(objectMapper.writeValueAsString(custresp));
		                    String hash = CryptoUtils.createSHAHash(encrypted_String);
		                    respmodel = new ActualReqResp(encrypted_String, hash);
		                    return respmodel;
		                } else {
		                    List<CustomerTransactionSummary.TransactionDetail> transactionDetails = transactions.stream()
		                            .map(t -> {
		                                CustomerTransactionSummary.TransactionDetail detail = new CustomerTransactionSummary.TransactionDetail();
		                                detail.setTransaction_id(t.getTransaction_id());
		                                detail.setAmount(t.getAmount());
		                                detail.setTransaction_type(t.getTransactiontype());
		                                detail.setTransaction_date(t.getTransactiondate());
		                                return detail;
		                            }).collect(Collectors.toList());

		                    CustomerTransactionSummary summary = new CustomerTransactionSummary();
		                    summary.setCustomerId(customer.getCustomer_id());
		                    summary.setCustomerName(customer.getFname() + customer.getLname());
		                    summary.setCustomerEmail(customer.getEmail());
		                    summary.setTransactions(transactionDetails);

		                    CustomResponse custresp = new CustomResponse("200", "Successfuly fetch the data", summary);
		                    String encrypted_String = CryptoUtils.encrypt(objectMapper.writeValueAsString(custresp));
		                    String hash = CryptoUtils.createSHAHash(encrypted_String);
		                    respmodel = new ActualReqResp(encrypted_String, hash);
		                    return respmodel;

		                }
		            } else {
		                CustomResponse custresp = new CustomResponse("201", "invalid credential token", null);
		                String encrypted_String = CryptoUtils.encrypt(objectMapper.writeValueAsString(custresp));
		                String hash = CryptoUtils.createSHAHash(encrypted_String);
		                respmodel = new ActualReqResp(encrypted_String, hash);
		                return respmodel;
		            }
		        } else {
		            CustomResponse custresp = new CustomResponse("201", "Invalid Hash", null);
		            String encrypted_String = CryptoUtils.encrypt(objectMapper.writeValueAsString(custresp));
		            String hash = CryptoUtils.createSHAHash(encrypted_String);
		            respmodel = new ActualReqResp(encrypted_String, hash);
		            return respmodel;
		        }
		    }

		    // Transaction get by account number

		    public ActualReqResp transaction_get_by_accno(String autherizationHeader, ActualReqResp body) throws Exception {
		        ActualReqResp respmodel;
		        
		        String plainJsonReq = cryptoutils.decrypt(body.getEncrypt());
		        String hash1 = cryptoutils.createSHAHash(plainJsonReq);
		        ObjectMapper objectMapper = new ObjectMapper();
		        Account_Details accdetails = objectMapper.readValue(plainJsonReq, Account_Details.class);
		        System.out.println(accdetails);

		        if (hash1.equals(body.getHash())) {
		            if (validateToken(autherizationHeader)) {

		                String status = "y";
		                Account_Details acc = accountdetailrepository.findByAccountnumber(accdetails.getAccountnumber());

		                Customer cu = acc.getCustomer();
		                if (!cu.getStatus().equals(status)) {
		                    return null;
		                }
		                if (acc == null) {
		                    return null;
		                }

		                long accno = acc.getAccountnumber();

		                List<Transaction_Details> td = transrepo.findByAccountnumber(accno);
		                if (td.isEmpty()) {
		                    CustomResponse custresp = new CustomResponse("201", "No trasactions found for given account number",
		                            null);
		                    String encrypted_String = CryptoUtils.encrypt(objectMapper.writeValueAsString(custresp));
		                    String hash = CryptoUtils.createSHAHash(encrypted_String);
		                    respmodel = new ActualReqResp(encrypted_String, hash);
		                    return respmodel;
		                } else {
		                    CustomResponse custresp = new CustomResponse("200", "Successfuly fetch the data", td);
		                    String encrypted_String = CryptoUtils.encrypt(objectMapper.writeValueAsString(custresp));
		                    String hash = CryptoUtils.createSHAHash(encrypted_String);
		                    respmodel = new ActualReqResp(encrypted_String, hash);
		                    return respmodel;

		                }
		            } else {
		                CustomResponse custresp = new CustomResponse("201", "invalid credential token", null);
		                String encrypted_String = CryptoUtils.encrypt(objectMapper.writeValueAsString(custresp));
		                String hash = CryptoUtils.createSHAHash(encrypted_String);
		                respmodel = new ActualReqResp(encrypted_String, hash);
		                return respmodel;
		            }
		        } else {
		            CustomResponse custresp = new CustomResponse("201", "Invalid Hash", null);
		            String encrypted_String = CryptoUtils.encrypt(objectMapper.writeValueAsString(custresp));
		            String hash = CryptoUtils.createSHAHash(encrypted_String);
		            respmodel = new ActualReqResp(encrypted_String, hash);
		            return respmodel;
		        }
		    }

		    // Get all transactions
		    public ActualReqResp getAllTransaction(String autherizationHeader)
		            throws JsonProcessingException, NoSuchAlgorithmException {
		        ActualReqResp respmodel;
		        ObjectMapper objectmapper = new ObjectMapper();

		        if (validateToken(autherizationHeader)) {

		            List<Transaction_Details> td = transrepo.findAll();

		            if (td.isEmpty()) {
		                CustomResponse custresp = new CustomResponse("201", "No trasactions found for given customer", null);
		                String encrypted_String = CryptoUtils.encrypt(objectmapper.writeValueAsString(custresp));
		                String hash = CryptoUtils.createSHAHash(encrypted_String);
		                respmodel = new ActualReqResp(encrypted_String, hash);
		                return respmodel;
		            } else {

		                CustomResponse custresp = new CustomResponse("200", "Successfuly fetch the data", td);
		                String encrypted_String = CryptoUtils.encrypt(objectmapper.writeValueAsString(custresp));
		                String hash = CryptoUtils.createSHAHash(encrypted_String);
		                respmodel = new ActualReqResp(encrypted_String, hash);
		                return respmodel;
		            }

		        } else {
		            CustomResponse custresp = new CustomResponse("201", "invalid credential token", null);
		            String encrypted_String = CryptoUtils.encrypt(objectmapper.writeValueAsString(custresp));
		            String hash = CryptoUtils.createSHAHash(encrypted_String);
		            respmodel = new ActualReqResp(encrypted_String, hash);
		            return respmodel;
		        }

		    }

		    // Transaction get by date
		    public ActualReqResp getTransactionByDate(String autherizationHeader, ActualReqResp body) throws Exception {
		        ActualReqResp respmodel;
		        String plainJsonReq = cryptoutils.decrypt(body.getEncrypt());
		        String hash1 = cryptoutils.createSHAHash(plainJsonReq);
		        ObjectMapper objectMapper = new ObjectMapper();
		        Transaction_Details td = objectMapper.readValue(plainJsonReq, Transaction_Details.class);

		        if (hash1.equals(body.getHash())) {
		            if (validateToken(autherizationHeader)) {

		                String status = "y";
		                Date date = td.getTransactiondate();
		                System.out.println(date);
		                List<Transaction_Details> transdate = transrepo.findByTransactiondate(td.getTransactiondate());
		                if (transdate == null) {
		                    return null;
		                }

		                if (transdate.isEmpty()) {
		                    CustomResponse custresp = new CustomResponse("201", "No trasactions found for given date", null);
		                    String encrypted_String = CryptoUtils.encrypt(objectMapper.writeValueAsString(custresp));
		                    String hash = CryptoUtils.createSHAHash(encrypted_String);
		                    respmodel = new ActualReqResp(encrypted_String, hash);
		                    return respmodel;
		                } else {
		                    CustomResponse custresp = new CustomResponse("200", "Successfuly fetch the data", transdate);
		                    String encrypted_String = CryptoUtils.encrypt(objectMapper.writeValueAsString(custresp));
		                    String hash = CryptoUtils.createSHAHash(encrypted_String);
		                    respmodel = new ActualReqResp(encrypted_String, hash);
		                    return respmodel;

		                }
		            } else {
		                CustomResponse custresp = new CustomResponse("201", "invalid credential token", null);
		                String encrypted_String = CryptoUtils.encrypt(objectMapper.writeValueAsString(custresp));
		                String hash = CryptoUtils.createSHAHash(encrypted_String);
		                respmodel = new ActualReqResp(encrypted_String, hash);
		                return respmodel;
		            }
		        } else {
		            CustomResponse custresp = new CustomResponse("201", "Invalid Hash", null);
		            String encrypted_String = CryptoUtils.encrypt(objectMapper.writeValueAsString(custresp));
		            String hash = CryptoUtils.createSHAHash(encrypted_String);
		            respmodel = new ActualReqResp(encrypted_String, hash);
		            return respmodel;
		        }
		    }
		    
		    // Transaction get between dates

		    public ActualReqResp getTransactionBetweenDate(String autherizationHeader, ActualReqResp body) throws Exception {

		        ActualReqResp respmodel;
		        String plainJsonReq = cryptoutils.decrypt(body.getEncrypt());
		        String hash1 = cryptoutils.createSHAHash(plainJsonReq);
		        ObjectMapper objectMapper = new ObjectMapper();
		        DateBetween tdate = objectMapper.readValue(plainJsonReq, DateBetween.class);

		        if (hash1.equals(body.getHash())) {
		            if (validateToken(autherizationHeader)) {
		                Date startDate = tdate.getStartDate();
		                Date endDate = tdate.getEndDate();

		                List<Transaction_Details> transdate = transrepo.findByTransactiondateBetween(startDate, endDate);
		                if (transdate == null) {
		                    return null;
		                }

		                if (transdate.isEmpty()) {
		                    CustomResponse custresp = new CustomResponse("201", "No trasactions found for given dates", null);
		                    String encrypted_String = CryptoUtils.encrypt(objectMapper.writeValueAsString(custresp));
		                    String hash = CryptoUtils.createSHAHash(encrypted_String);
		                    respmodel = new ActualReqResp(encrypted_String, hash);
		                    return respmodel;
		                } else {
		                    CustomResponse custresp = new CustomResponse("200", "Successfuly fetch the data", transdate);
		                    String encrypted_String = CryptoUtils.encrypt(objectMapper.writeValueAsString(custresp));
		                    String hash = CryptoUtils.createSHAHash(encrypted_String);
		                    respmodel = new ActualReqResp(encrypted_String, hash);
		                    return respmodel;

		                }
		            } else {
		                CustomResponse custresp = new CustomResponse("201", "invalid credential token", null);
		                String encrypted_String = CryptoUtils.encrypt(objectMapper.writeValueAsString(custresp));
		                String hash = CryptoUtils.createSHAHash(encrypted_String);
		                respmodel = new ActualReqResp(encrypted_String, hash);
		                return respmodel;
		            }
		        } else {
		            CustomResponse custresp = new CustomResponse("201", "Invalid Hash", null);
		            String encrypted_String = CryptoUtils.encrypt(objectMapper.writeValueAsString(custresp));
		            String hash = CryptoUtils.createSHAHash(encrypted_String);
		            respmodel = new ActualReqResp(encrypted_String, hash);
		            return respmodel;
		        }

		    }
		    
		    


		    
		    
		    
		    
		    
		    
		    
		    
		    
		    
		    
		    

public ResponseEntity requestCheckBook(ActualReqResp body, String token)
            throws NoSuchAlgorithmException, JsonMappingException, JsonProcessingException {

        if (validateToken(token)) {
            String decryp = CryptoUtils.decrypt(body.getEncrypt());
            String hash = CryptoUtils.getCheckSumValue(decryp,"SHA256");
            if (hash.equals(body.getHash())) {
                ObjectMapper obj = new ObjectMapper();
                CheckBook checkBook = obj.readValue(decryp, CheckBook.class);
                Account_Details accountDetails = accountdetailrepository
                        .findByAccountnumber(checkBook.getAccountnumber());

                if (accountDetails == null) {

                    String message= "No account found";
                    ResponseModel response = new ResponseModel(message,"200");
                    ObjectMapper objResponse = new ObjectMapper();
                    String responseStr = objResponse.writeValueAsString(response);
                    String encrypt = CryptoUtils.encrypt(responseStr);
                    String responseHash =  CryptoUtils.getCheckSumValue(responseStr,"SHA256");

                    ActualReqResp actualResponse = new ActualReqResp(encrypt, responseHash );
                    
                    return ResponseEntity.status(200).body(actualResponse);
                
                } else {
                    Customer customer = accountDetails.getCustomer();
                    if ((customer.getStatus()).equals("Y") || (customer.getStatus()).equals("y")) {
                        checkBook.setAccountDetails(accountDetails);
                        checkBook.setCreated_by(customer.getFname() + " " + customer.getLname());
                        long millis = System.currentTimeMillis();
                        java.sql.Date date = new java.sql.Date(millis);
                        checkBook.setCreated_on(date);
                        String referenceNo = "RF" + generateReferenceNumber();
                        boolean Flag = true;
                        while (Flag) {
                            Optional<CheckBook> referenceNoPresent = checkBookRepo.findByReferenceNo(referenceNo);
                            if (referenceNoPresent.isPresent()) {
                                referenceNo = "RF" + generateReferenceNumber();
                            } else {
                                checkBook.setReferenceNo(referenceNo);
                                Flag = false;
                            }
                        }

                        checkBook.setStatus("Y");
                        CheckBook checkBookSave = checkBookRepo.save(checkBook);
                        if(checkBookSave!=null) {
                                                    
                        ResponseForCheckBook responseCheckBook = new ResponseForCheckBook(checkBookSave,"200","CheckBook Request added successfully");
                        ObjectMapper objResponse = new ObjectMapper();
                        String responseStr = objResponse.writeValueAsString(responseCheckBook);
                        String encrypt = CryptoUtils.encrypt(responseStr);
                        String responseHash =CryptoUtils.getCheckSumValue(responseStr,"SHA256");
                        ActualReqResp response = new ActualReqResp(encrypt, responseHash );
                        ObjectMapper obj1 = new ObjectMapper();
                        
                    
                        String fileName = "requestCheckBook";
                        MyTools.createLog("/requestCheckBook", decryp, responseStr, obj1.writeValueAsString(body),obj1.writeValueAsString(response), fileName);
                        
                        return ResponseEntity.status(200).body(response);
                        }
                        else {
                            String message= "Error while storing thr data";
                            ResponseModel response = new ResponseModel(message,"200");
                            ObjectMapper objResponse = new ObjectMapper();
                            String responseStr = objResponse.writeValueAsString(response);
                            String encrypt = CryptoUtils.encrypt(responseStr);
                            String responseHash = CryptoUtils.getCheckSumValue(responseStr,"SHA256");
    
                            ActualReqResp actualResponse = new ActualReqResp(encrypt, responseHash );
                            return ResponseEntity.status(200).body(actualResponse);
                        }
                    } else {
                        
                        String message= "Account Dosen't Exist";
                        ResponseModel response = new ResponseModel(message,"200");
                        ObjectMapper objResponse = new ObjectMapper();
                        String responseStr = objResponse.writeValueAsString(response);
                        String encrypt = CryptoUtils.encrypt(responseStr);
                        String responseHash =CryptoUtils.getCheckSumValue(responseStr,"SHA256");

                        ActualReqResp actualResponse = new ActualReqResp(encrypt, responseHash );
                        return ResponseEntity.status(200).body(actualResponse);
                    

                    }
                }
            } else {

                String message= "Hash Not matched";
                ResponseModel response = new ResponseModel(message,"200");
                ObjectMapper objResponse = new ObjectMapper();
                String responseStr = objResponse.writeValueAsString(response);
                String encrypt = CryptoUtils.encrypt(responseStr);
                String responseHash = CryptoUtils.getCheckSumValue(responseStr,"SHA256");

                ActualReqResp actualResponse = new ActualReqResp(encrypt, responseHash );
                return ResponseEntity.status(200).body(actualResponse);
            
            }
        } else {
            String message= "Not a Valid Token";
            ResponseModel response = new ResponseModel(message,"200");
            ObjectMapper objResponse = new ObjectMapper();
            String responseStr = objResponse.writeValueAsString(response);
            String encrypt = CryptoUtils.encrypt(responseStr);
            String responseHash =CryptoUtils.getCheckSumValue(responseStr,"SHA256");

            ActualReqResp actualResponse = new ActualReqResp(encrypt, responseHash );
            return ResponseEntity.status(200).body(actualResponse);
        
        }
    }

    public static String generateReferenceNumber() {

        String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        StringBuilder alphaPart = new StringBuilder(4);
        Random random = new Random();

        for (int i = 0; i < 4; i++) {
            int index = random.nextInt(alphabet.length());
            alphaPart.append(alphabet.charAt(index));
        }

        StringBuilder digitPart = new StringBuilder(4);

        for (int i = 0; i < 4; i++) {
            int digit = random.nextInt(10);
            digitPart.append(digit);
        }

        // Combine both parts
        return alphaPart.toString() + digitPart.toString();
    }

    public ResponseEntity decryptRequestCheckBook( ActualReqResp body) throws NoSuchAlgorithmException, JsonMappingException, JsonProcessingException {
        String decrypt = CryptoUtils.decrypt(body.getEncrypt());
        String hash =CryptoUtils.getCheckSumValue(decrypt,"SHA256");
        if(hash.equals(body.getHash())) {
            ObjectMapper objrespo = new ObjectMapper();
            ResponseForCheckBook responseForCheckBook = objrespo.readValue(decrypt, ResponseForCheckBook.class);
//            ObjectMapper objtostring = new ObjectMapper();
//            String data = objtostring.writeValueAsString(responseForCheckBook.getData());
//            CheckBook checkBook = objtostring.readValue(data, CheckBook.class);
            return ResponseEntity.status(200).body(responseForCheckBook);
        }
        else {
            return ResponseEntity.status(200).body("Hash not mached");
        }
    }

    
    
    
    
    

public ResponseEntity ListOfRequestedCheckBook(ActualReqResp body, String token) throws NoSuchAlgorithmException, JsonMappingException, JsonProcessingException {
        if(validateToken(token)) {
            String decrypt = CryptoUtils.decrypt(body.getEncrypt());
            String hash = CryptoUtils.getCheckSumValue(decrypt, "SHA256");
            if(hash.equals(body.getHash())) {
                ObjectMapper obj = new ObjectMapper();
                Bank_Staff list = obj.readValue(decrypt, Bank_Staff.class);
                Optional<Bank_Staff> id = bankstaffrepo.findById(list.getStaff_id());
                if(id.isPresent()) {
                
                List<CheckBook> bankstaff = (List<CheckBook>) checkBookRepo.findAll();
                ResponseForCheckBook responseCheckBook = new ResponseForCheckBook(bankstaff,"200","CheckBook Request shown successfully");
                ObjectMapper objResponse = new ObjectMapper();
                String responseStr = objResponse.writeValueAsString(responseCheckBook);
                String encrypt = CryptoUtils.encrypt(responseStr);
                String responseHash = CryptoUtils.getCheckSumValue(responseStr, "SHA256");
                ActualReqResp response = new ActualReqResp(encrypt, responseHash );
            
                return ResponseEntity.status(200).body(response);
                }
                else {
                    
                    String message= "User not Authorized";
                    ResponseModel response = new ResponseModel(message,"200");
                    ObjectMapper objResponse = new ObjectMapper();
                    String responseStr = objResponse.writeValueAsString(response);
                    String encrypt = CryptoUtils.encrypt(responseStr);
                    String responseHash = CryptoUtils.getCheckSumValue(responseStr, "SHA256");

                    ActualReqResp actualResponse = new ActualReqResp(encrypt, responseHash );
                    return ResponseEntity.status(200).body(actualResponse);
                }
            }
            else {
                String message= "Hash not equal";
                ResponseModel response = new ResponseModel(message,"200");
                ObjectMapper objResponse = new ObjectMapper();
                String responseStr = objResponse.writeValueAsString(response);
                String encrypt = CryptoUtils.encrypt(responseStr);
                String responseHash = CryptoUtils.getCheckSumValue(responseStr, "SHA256");

                ActualReqResp actualResponse = new ActualReqResp(encrypt, responseHash );
                return ResponseEntity.status(200).body(actualResponse);
            }
        }
        else {
            String message= "Incorrect Token ";
            ResponseModel response = new ResponseModel(message,"200");
            ObjectMapper objResponse = new ObjectMapper();
            String responseStr = objResponse.writeValueAsString(response);
            String encrypt = CryptoUtils.encrypt(responseStr);
            String responseHash = CryptoUtils.getCheckSumValue(responseStr, "SHA256");

            ActualReqResp actualResponse = new ActualReqResp(encrypt, responseHash );
            return ResponseEntity.status(200).body(actualResponse);
        }
        
    }

















public ActualReqResp Details(ActualReqResp Ad, String authorizationHeader) throws Exception {

    String decrypt = CryptoUtils.decrypt(Ad.getEncrypt());
    
    String hashoriginal = Ad.getHash();
    String hash = CryptoUtils.createSHAHash(decrypt);
    
    System.out.println(hashoriginal);
    System.out.println(hash);
    
    if (hashoriginal.equals(hash)) {
    ObjectMapper objectmapper = new ObjectMapper();
    JsonNode jsonnode = objectmapper.readTree(decrypt);

    Account_Details em = new Account_Details();

    long id = jsonnode.get("customer_id").asLong();

    long Staff_id = jsonnode.get("Staff_id").asLong();
    String Acc_type1 = jsonnode.get("accounttype").asText();
    long balance = jsonnode.get("balance").asLong();

    boolean valid = validateToken(authorizationHeader);
    if (valid == true )       {

        Optional<Customer> customer = bankrepo.findById(id);
          
        Customer obj = customer.get();
        System.out.println(obj);
        String Status1 = obj.getStatus();
        String Status2 = "y";
     
        System.out.println(Acc_type1);

        long pin = obj.getPincode();

        pincode data = pinrepo.findBypincode(pin);
        String bname = data.getBranch_name();
        String code = data.getIFSC();

        long number = accountdetailrepository.countByCustomerAndAccounttype(obj, Acc_type1);

        if(Status1.equals(Status2)) {
            if (number < 1   ) {

                long min = 100000000000L;
                long max = 999999999999L;

                Random random = new Random();
                long Acountrandom = min + ((long) (random.nextDouble() * (max - min)));

                em.setAccountnumber(Acountrandom);
                em.setCustomer(obj);

                long millis = System.currentTimeMillis();
                java.sql.Date date = new java.sql.Date(millis);
                em.setCreated_on(date);

                Bank_Staff staff = bankstaffrepo.findById(Staff_id).get();

                String fname = staff.getFname();
                String lname = staff.getLname();
                String staffname = fname + lname;
                em.setBalance(balance);
                em.setAccounttype(Acc_type1);
                em.setCreated_by(staffname);
                em.setBranch_name(bname);
                em.setIFSC(code);
                String strAcountrandom = Long.toString(Acountrandom);
                accountdetailrepository.save(em);

                ResponeAccountnum res = new ResponeAccountnum("Account generated succesfully ", "200", Acountrandom);

                String encData = cryptoutils.encrypt(String.valueOf(res));
                String reqHash = cryptoutils.createSHAHash(encData);
                 String fileName = "NewAccount";
                  MyTools.createLog("/create", decrypt,objectmapper.writeValueAsString(res), objectmapper.writeValueAsString(Ad),
                          objectmapper.writeValueAsString(new ActualReqResp(encData, reqHash)), fileName);
                 
                  
                return new ActualReqResp(encData, reqHash);

            }

            else {

                ResponseModel respmodel = new ResponseModel("Account already exits  !!", "200");
                String encData = cryptoutils.encrypt(String.valueOf(respmodel));
                String reqHash = cryptoutils.createSHAHash(encData);
                
                 String fileName = "AcccountExist";
                  MyTools.createLog("/create", decrypt,objectmapper.writeValueAsString(respmodel), objectmapper.writeValueAsString(Ad),
                          objectmapper.writeValueAsString(new ActualReqResp(encData, reqHash)), fileName);
                 

                return new ActualReqResp(encData, reqHash);

            }

        }   else {
            ResponseModel respmodel = new ResponseModel("Status Not Active", "201");
            String encData = cryptoutils.encrypt(String.valueOf(respmodel));
            String reqHash = cryptoutils.createSHAHash(encData);
             String fileName = "NOTActive";
              MyTools.createLog("/create", decrypt,objectmapper.writeValueAsString(respmodel), objectmapper.writeValueAsString(Ad),
                      objectmapper.writeValueAsString(new ActualReqResp(encData, reqHash)), fileName);
             
            return new ActualReqResp(encData, reqHash);
        }
    
    }

    ResponseModel respmodel = new ResponseModel("Invalid Token !!", "201");
    String encData = cryptoutils.encrypt(String.valueOf(respmodel));
    String reqHash = cryptoutils.createSHAHash(encData);

    return new ActualReqResp(encData, reqHash);
}   else {
    
    
    ResponseModel respmodel = new ResponseModel("Hash Validation failed !!", "201");
    String encData = cryptoutils.encrypt(String.valueOf(respmodel));
    String reqHash = cryptoutils.createSHAHash(encData);
    return new ActualReqResp(encData, reqHash);
    
    
}
    
}
















public ActualReqResp transfer(ActualReqResp Ad, String authorizationHeader) throws Exception {

        boolean valid = validateToken(authorizationHeader);

        if (valid == true) {
            String decrypt = CryptoUtils.decrypt(Ad.getEncrypt());
            String hashoriginal = Ad.getHash();
            String hash = CryptoUtils.createSHAHash(decrypt);
            if (hashoriginal.equals(hash)) {

                ObjectMapper objectmapper = new ObjectMapper();
                JsonNode jsonnode = objectmapper.readTree(decrypt);

                long FromAccount = jsonnode.get("FromAccount").asLong();

                long TOAccount = jsonnode.get("TOAccount").asLong();
                ;

                long amount = jsonnode.get("ammount").asLong();

                System.out.println(amount);
                Account_Details balanceFrom = accountdetailrepository.findByaccountnumber(FromAccount);
                Double amountfrom = balanceFrom.getBalance();
                System.out.println(amountfrom);

                Account_Details balanceTO = accountdetailrepository.findByaccountnumber(TOAccount);
                Double amountto = balanceTO.getBalance();
                System.out.println(amountto);

                if (amount > amountfrom) {

                    ResponseModel respmodel = new ResponseModel(" Not sufficient funds ", "201");
                    String encData = cryptoutils.encrypt(String.valueOf(respmodel));
                    String reqHash = cryptoutils.createSHAHash(encData);

                    return new ActualReqResp(encData, reqHash);

                }

                else {
                    // below is the logic for transfer money from one to another
                    double finalamount = amountfrom - amount;
                    balanceFrom.setBalance(finalamount);
                    double actualbalance = amountto + amount;
                    System.out.println(finalamount);
                    System.out.println(actualbalance);
                    balanceTO.setBalance(actualbalance);
                    long millis = System.currentTimeMillis();
                    java.sql.Date date = new java.sql.Date(millis);
                    balanceFrom.setModified_on(date);
                    balanceTO.setModified_on(date);
                    long id = balanceFrom.getCustomer().getCustomer_id();
                    Customer customer1 = bankrepo.findById(id).get();
                    String fname = customer1.getFname();
                    String lname = customer1.getLname();
                    String Depositername = fname + lname;
                    balanceFrom.setModified_by(Depositername);
                    balanceTO.setModified_by(Depositername);
                    // to update a balance in both the account i.e Reciever as well as Sender
                    accountdetailrepository.save(balanceFrom);
                    accountdetailrepository.save(balanceTO);
                    // below code is to update Transaction table for both the account number
                    Transaction_Details TD = new Transaction_Details();
                    TD.setAmount((long) amount);
                    TD.setCustomer(customer1);
                    TD.setCreated_by(Depositername);
                    TD.setTransactiondate(date);
                    TD.setCreated_on(date);
                    TD.setTransactiontype("MoneyTransfer");
                    long min = 100000L;
                    long max = 9999999L;
                    Random random = new Random();
                    long trsID = min + ((long) (random.nextDouble() * (max - min)));
                    TD.setTransaction_id(trsID);
                    TD.setAccountnumber(FromAccount);

                    Transaction_Details PD = new Transaction_Details();
                    Customer customer2 = balanceTO.getCustomer();
                    long cus_id = customer2.getCustomer_id();

                    String DFname = customer2.getFname();
                    String DLname = customer2.getLname();
                    String FULLNAME = DFname + DLname;
                    PD.setTransactiondate(date);
                    PD.setCreated_on(date);
                    PD.setAmount((long) amount);

                    PD.setCreated_by(FULLNAME);
                    PD.setAccountnumber(TOAccount);
              
                    PD.setCustomer(customer2);
                    long minn = 100000L;
                    long maxx = 9999999L;
                    Random random2 = new Random();
                    long trsIDD = min + ((long) (random2.nextDouble() * (maxx - minn)));
                    PD.setTransaction_id(trsIDD);
                    PD.setTransactiontype("MoneyTransfer");

                    transrepo.save(PD);
                    transrepo.save(TD);

                    ResponseModel respmodel = new ResponseModel("Money transfer sucessfully ", "200");
                    String encData = cryptoutils.encrypt(String.valueOf(respmodel));
                    String reqHash = cryptoutils.createSHAHash(encData);
                     
                      String fileName = "MoneyTransfer";
                      MyTools.createLog("/userlogin", decrypt,objectmapper.writeValueAsString(respmodel), objectmapper.writeValueAsString(Ad),
                              objectmapper.writeValueAsString(new ActualReqResp(encData, reqHash)), fileName);
                     
                      
                    return new ActualReqResp(encData, reqHash);

                }
            }

            else {
                ResponseModel respmodel = new ResponseModel(" Hash validation failed  ", "201");
                String encData = cryptoutils.encrypt(String.valueOf(respmodel));
                String reqHash = cryptoutils.createSHAHash(encData);

                return new ActualReqResp(encData, reqHash);
            }

        }

        ResponseModel respmodel = new ResponseModel("Authorization not Sucessfull ", "201");
        String encData = cryptoutils.encrypt(String.valueOf(respmodel));
        String reqHash = cryptoutils.createSHAHash(encData);

        return new ActualReqResp(encData, reqHash);

    }




















public ActualReqResp updateCustomer(ActualReqResp req) throws JsonMappingException, JsonProcessingException {
    ResponseModel resp;

    String plainJsonReq = CryptoUtils.decrypt(req.getEncrypt());
    String decrypthash = CryptoUtils.getCheckSumValue(plainJsonReq, "SHA256");

    ObjectMapper obj = new ObjectMapper();

    if (req.getHash().equals(decrypthash)) {

        JSONObject json = new JSONObject(plainJsonReq);
        System.out.println(json);

        Object ob1 = json.opt("id");
        String str1 = ob1.toString();
        long id = Long.parseLong(str1);
        System.out.println(id);

        Object ob2 = json.opt("email");
        String email = ob2.toString();

        Object ob3 = json.opt("address");
        String address = ob3.toString();

        Optional<Customer> byId = bankrepo.findById(id);
        Customer b = byId.get();
        if (b.getStatus().equals("y")) {
            b.setAddress(address);
            b.setEmail(email);

            String name = b.getFname() + " " + b.getLname();
            b.setModified_by(name);
            long millis = System.currentTimeMillis();
            java.sql.Date date = new java.sql.Date(millis);
            b.setModified_on(date);
            User_Master user = new User_Master(b.getEmail(), b.getPassword(), "Customer", b);

            bankuser.save(user);

            resp = new ResponseModel("Bank Customer Updated Sucessfully", "200");

            String plainJsonResp = obj.writeValueAsString(resp);

            String encrypt = CryptoUtils.encrypt(plainJsonResp);
            String encrypthash = CryptoUtils.getCheckSumValue(plainJsonReq, "SHA256");
            ActualReqResp actRespObj = new ActualReqResp(encrypt, encrypthash);
            String fileName = "userlogin";
            MyTools.createLog("/userlogin", plainJsonReq, plainJsonResp, obj.writeValueAsString(req),
                    obj.writeValueAsString(actRespObj), fileName);
            return actRespObj;
        }

        else {
            ResponseModel m = new ResponseModel("Bank Customer not present for this id", "404");
            String encrypt = CryptoUtils.encrypt(m.toString());
            String encrypthash = CryptoUtils.getCheckSumValue(plainJsonReq, "SHA256");
            ActualReqResp ar = new ActualReqResp(encrypt, encrypthash);
            return ar;
        }

    } else {
        resp = new ResponseModel("Hash are not equal", "400");

        String plainJsonResp = obj.writeValueAsString(resp);

        String encrypt = CryptoUtils.encrypt(plainJsonResp);
        String encrypthash = CryptoUtils.getCheckSumValue(plainJsonReq, "SHA256");
        ActualReqResp actRespObj = new ActualReqResp(encrypt, encrypthash);
        return actRespObj;
    }

}



public ActualReqResp getEncryptedStaffById(String authorization, ActualReqResp body)
        throws NoSuchAlgorithmException, JsonProcessingException {
    String decrypt = CryptoUtils.decrypt(body.getEncrypt());
    String decrypthash = CryptoUtils.getCheckSumValue(decrypt, "SHA256");
    ResponseModel resp;

    if (body.getHash().equals(decrypthash)) {
        JSONObject json = new JSONObject(decrypt);

        Object ob = json.opt("id");

        String st = ob.toString();

        System.out.println(ob);

        long id = Long.valueOf(st);

        if (validateToken(authorization)) {
            Optional<Bank_Staff> byId = bankstaffrepo.findById(id);
            Bank_Staff bank_Staff = byId.get();

            if (bank_Staff.getStatus().equals("y"))

            {
                PlainResponce p = new PlainResponce(bank_Staff, "Bank Staff Data fetch Sucessfully", "200");
                ObjectMapper o = new ObjectMapper();
                String str = o.writeValueAsString(p);

                String encrypt = CryptoUtils.encrypt(str);
                String hashdecrpted = CryptoUtils.getCheckSumValue(encrypt, "SHA256");

                ActualReqResp as = new ActualReqResp(encrypt, hashdecrpted);

                return as;

            } else {
                resp = new ResponseModel("Bank Staff not present for this id", "404");
                String encrypt = CryptoUtils.encrypt(resp.toString());
                String encrypthash = CryptoUtils.getCheckSumValue(encrypt, "SHA256");
                ActualReqResp ar = new ActualReqResp(encrypt, encrypthash);
                return ar;
            }

        } else {
            resp = new ResponseModel("Token not Validated", "404");
            String encrypt = CryptoUtils.encrypt(resp.toString());
            String encrypthash = CryptoUtils.getCheckSumValue(encrypt, "SHA256");
            ActualReqResp ar = new ActualReqResp(encrypt, encrypthash);
            return ar;
        }

    } else {
        resp = new ResponseModel("Hash not Match", "404");
        String encrypt = CryptoUtils.encrypt(resp.toString());
        String encrypthash = CryptoUtils.getCheckSumValue(encrypt, "SHA256");
        ActualReqResp ar = new ActualReqResp(encrypt, encrypthash);
        return ar;
    }

}

public ActualReqResp plainToEncrypt(Bank_Staff staff) throws NoSuchAlgorithmException, JsonProcessingException {

    ObjectMapper obj = new ObjectMapper();
    String writeValueAsString = obj.writeValueAsString(staff);
    // System.out.println(writeValueAsString);
    String encrypt = CryptoUtils.encrypt(writeValueAsString);
    String hash = CryptoUtils.getCheckSumValue(writeValueAsString, "SHA256");

    ActualReqResp as = new ActualReqResp(encrypt, hash);

    return as;

}

public ActualReqResp deleteStaff(ActualReqResp req)
        throws NoSuchAlgorithmException, JsonMappingException, JsonProcessingException {

    ResponseModel resp;

    String plainJsonReq = CryptoUtils.decrypt(req.getEncrypt());
    String decrypthash = CryptoUtils.getCheckSumValue(plainJsonReq, "SHA256");
    ObjectMapper obj = new ObjectMapper();
    if (req.getHash().equals(decrypthash)) {
        JSONObject json = new JSONObject(plainJsonReq);

        Object ob = json.opt("id");

        String st = ob.toString();

        System.out.println(ob);

        long id = Long.valueOf(st);
        System.out.println(id);

        Optional<Bank_Staff> byId = bankstaffrepo.findById(id);
        Bank_Staff bank_Staff = byId.get();
        System.out.println(bank_Staff);
        if (bank_Staff.getStatus().equals("y")) {
            bank_Staff.setStatus("n");
            bankstaffrepo.save(bank_Staff);
            System.out.println(bankstaffrepo.save(bank_Staff));
//        
            resp = new ResponseModel("Bank Staff Deleted Sucessfully", "200");

            String plainJsonResp = obj.writeValueAsString(resp);

            String encrypt = CryptoUtils.encrypt(plainJsonResp);
            String encrypthash = CryptoUtils.createSHAHash(resp.toString());
            ActualReqResp actRespObj = new ActualReqResp(encrypt, encrypthash);
            String fileName = "userlogin";
            MyTools.createLog("/userlogin", plainJsonReq, plainJsonResp, obj.writeValueAsString(req),
                    obj.writeValueAsString(actRespObj), fileName);
            return actRespObj;

        }

        else {
            ResponseModel m = new ResponseModel("Bank Staff not present for this id", "404");
            String encrypt = CryptoUtils.encrypt(m.toString());
            String encrypthash = CryptoUtils.createSHAHash(m.toString());
            ActualReqResp ar = new ActualReqResp(encrypt, encrypthash);
            return ar;
        }
    }

    else {
        resp = new ResponseModel("Hash are not equal", "400");

        String plainJsonResp = obj.writeValueAsString(resp);

        String encrypt = CryptoUtils.encrypt(plainJsonResp);
        String encrypthash = CryptoUtils.createSHAHash(resp.toString());
        ActualReqResp actRespObj = new ActualReqResp(encrypt, encrypthash);
        return actRespObj;
    }

}


public ActualReqResp addStaffEnrypted(ActualReqResp as) throws Exception {

    ResponseModel resp;

    String plainJsonReq = CryptoUtils.decrypt(as.getEncrypt());
    String decrypthash = CryptoUtils.getCheckSumValue(plainJsonReq, "SHA256");

    ObjectMapper obj = new ObjectMapper();

    if (as.getHash().equals(decrypthash)) {

        Bank_Staff staff = obj.readValue(plainJsonReq, Bank_Staff.class);

        staff.setCreated_by("Admin");
        long millis = System.currentTimeMillis();
        java.sql.Date date = new java.sql.Date(millis);
        staff.setCreated_on(date);

        Bank_Staff bs = bankstaffrepo.save(staff);

        System.out.println(bs);
        User_Master user = new User_Master(bs.getEmail(), staff.getPassword(), "Bank Staff", bs);
        bankuser.save(user);

        resp = new ResponseModel("Bank Staff data added sucessfully", "200");

        String plainJsonResp = obj.writeValueAsString(resp);

        String encrypt = CryptoUtils.encrypt(plainJsonResp);
        String encrypthash = CryptoUtils.createSHAHash(resp.toString());
        ActualReqResp actRespObj = new ActualReqResp(encrypt, encrypthash);
        String fileName = "userlogin";
        MyTools.createLog("/userlogin", plainJsonReq, plainJsonResp, obj.writeValueAsString(as),
                obj.writeValueAsString(actRespObj), fileName);
        return actRespObj;
    } else {
        resp = new ResponseModel("Hash are not equal", "400");

        String plainJsonResp = obj.writeValueAsString(resp);

        String encrypt = CryptoUtils.encrypt(plainJsonResp);
        String encrypthash = CryptoUtils.createSHAHash(resp.toString());
        ActualReqResp actRespObj = new ActualReqResp(encrypt, encrypthash);
        return actRespObj;
    }

}







public ActualReqResp updateStaff(String authorization,ActualReqResp req) throws JsonMappingException, JsonProcessingException {
        ResponseModel resp;

        String plainJsonReq = CryptoUtils.decrypt(req.getEncrypt());
        String decrypthash = CryptoUtils.getCheckSumValue(plainJsonReq, "SHA256");

        ObjectMapper obj = new ObjectMapper();

        if (req.getHash().equals(decrypthash)) {

            JSONObject json = new JSONObject(plainJsonReq);
            System.out.println(json);

            Object ob1 = json.opt("id");
            String str1 = ob1.toString();
            long id = Long.parseLong(str1);
            System.out.println(id);

            Object ob2 = json.opt("email");
            String email = ob2.toString();

            Object ob3 = json.opt("address");
            String address = ob3.toString();
            if (validateToken(authorization)) {
            Optional<Bank_Staff> byId = bankstaffrepo.findById(id);
            Bank_Staff b = byId.get();
            if (b.getStatus().equals("y")) {
                b.setAddress(address);
                b.setEmail(email);

                String name = b.getFname() + " " + b.getLname();
                b.setModified_by(name);
                long millis = System.currentTimeMillis();
                java.sql.Date date = new java.sql.Date(millis);
                b.setModified_on(date);
                User_Master user = new User_Master(b.getEmail(), b.getPassword(), "Bank Staff", b);

                bankuser.save(user);

                resp = new ResponseModel("Bank Staff Updated Sucessfully", "200");

                String plainJsonResp = obj.writeValueAsString(resp);

                String encrypt = CryptoUtils.encrypt(plainJsonResp);
                String encrypthash = CryptoUtils.getCheckSumValue(plainJsonReq, "SHA256");
                ActualReqResp actRespObj = new ActualReqResp(encrypt, encrypthash);
                String fileName = "userlogin";
                MyTools.createLog("/userlogin", plainJsonReq, plainJsonResp, obj.writeValueAsString(req),
                        obj.writeValueAsString(actRespObj), fileName);
                return actRespObj;
            }
                else {
                    ResponseModel m = new ResponseModel("Bank Staff not present for this id", "404");
                    String encrypt = CryptoUtils.encrypt(m.toString());
                    String encrypthash = CryptoUtils.getCheckSumValue(plainJsonReq, "SHA256");
                    ActualReqResp ar = new ActualReqResp(encrypt, encrypthash);
                    return ar;
                }

            }
            else {
                resp = new ResponseModel("Token not Validated", "404");
                String encrypt = CryptoUtils.encrypt(resp.toString());
                String encrypthash = CryptoUtils.getCheckSumValue(encrypt, "SHA256");
                ActualReqResp ar = new ActualReqResp(encrypt, encrypthash);
                return ar;
            }

            
        } 
        
        else {
            resp = new ResponseModel("Hash are not equal", "400");

            String plainJsonResp = obj.writeValueAsString(resp);

            String encrypt = CryptoUtils.encrypt(plainJsonResp);
            String encrypthash = CryptoUtils.getCheckSumValue(plainJsonReq, "SHA256");
            ActualReqResp actRespObj = new ActualReqResp(encrypt, encrypthash);
            return actRespObj;
        }

    }
}








