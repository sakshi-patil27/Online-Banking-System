package com.banking.response;


public class ResponseForBalance {
	private String message;
	private double balance;
	private String status;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public ResponseForBalance(String message, double balance, String status) {
		super();
		this.message = message;
		this.balance = balance;
		this.status = status;
	}
	public ResponseForBalance() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ResponseForBalance [message=" + message + ", balance=" + balance + ", status=" + status + "]";
	}
	
}