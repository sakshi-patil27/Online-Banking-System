package com.banking.repository;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.banking.entity.CheckBook;
import com.banking.entity.Customer;

public interface CheckBookRepo extends CrudRepository<CheckBook, Long> {

    Optional<CheckBook> findByReferenceNo(String referenceNo);


}



