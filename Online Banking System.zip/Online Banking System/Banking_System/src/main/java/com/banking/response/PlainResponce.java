package com.banking.response;


import com.banking.entity.Bank_Staff;

public class PlainResponce {
    
    @Override
    public String toString() {
        return "PlainResponce [bankStaff=" + bankStaff + ", message=" + message + ", status=" + status + "]";
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public Bank_Staff getBankStaff() {
        return bankStaff;
    }
    public void setBankStaff(Bank_Staff bankStaff) {
        this.bankStaff = bankStaff;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    Bank_Staff bankStaff;
    String message;
    String status;
    public PlainResponce() {
        super();
    }
    public PlainResponce(Bank_Staff bankStaff,String message,  String status) {
        super();
        this.message = message;
        this.bankStaff = bankStaff;
        this.status = status;
    }
    

}





























