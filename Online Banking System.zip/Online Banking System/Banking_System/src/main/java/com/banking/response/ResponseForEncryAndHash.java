package com.banking.response;



public class ResponseForEncryAndHash {
	private String encrypt;
	private String status;
    private String hash;
    private String massage;
	public String getEncrypt() {
		return encrypt;
	}
	public void setEncrypt(String encrypt) {
		this.encrypt = encrypt;
	}
	public String getStatus() {
		return status;
	}

	@Override
	public String toString() {
		return "{\"massage\":\"" + massage + "\", \"status\":\"" + status + "\",\" encrypt\":\"" + encrypt + "\",\" hash\":\"" + hash +"\"}";
	}
	public ResponseForEncryAndHash(String massage, String status,String encrypt,String hash) {
		super();
		this.massage = massage;
		this.status = status;
		this.encrypt = encrypt;
		this.hash = hash;
		
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getHash() {
		return hash;
	}
	public void setHash(String hash) {
		this.hash = hash;
	}
	public String getMassage() {
		return massage;
	}
	public void setMassage(String massage) {
		this.massage = massage;
	}
    

}
