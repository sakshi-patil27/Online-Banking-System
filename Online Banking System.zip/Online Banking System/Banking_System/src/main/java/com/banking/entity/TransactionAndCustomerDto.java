package com.banking.entity;

import java.sql.Date;

public class TransactionAndCustomerDto {
	private long amount;
	private long accountnumber;
	private long customer_id;
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	public long getAccountnumber() {
		return accountnumber;
	}
	public void setAccountnumber(long accountnumber) {
		this.accountnumber = accountnumber;
	}
	public long getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(long customer_id) {
		this.customer_id = customer_id;
	}
	public TransactionAndCustomerDto(long amount, long accountnumber, long customer_id) {
		super();
		this.amount = amount;
		this.accountnumber = accountnumber;
		this.customer_id = customer_id;
	}
	public TransactionAndCustomerDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "TransactionAndCustomerDto [amount=" + amount + ", accountnumber=" + accountnumber + ", customer_id="
				+ customer_id + "]";
	}
	
}
