package com.banking.response;


public class ResponseForCheckBook {
    private Object data;
    private String status;
    private String message;
    public Object getData() {
        return data;
    }
    public void setData(Object data) {
        this.data = data;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    @Override
    public String toString() {
        return "ResponseForCheckBook [data=" + data + ", status=" + status + ", message=" + message + "]";
    }
    public ResponseForCheckBook(Object data, String status, String message) {
        super();
        this.data = data;
        this.status = status;
        this.message = message;
    }
    public ResponseForCheckBook() {
        super();
    }
    

}

