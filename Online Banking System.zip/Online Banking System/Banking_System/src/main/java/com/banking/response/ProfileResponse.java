package com.banking.response;

public class ProfileResponse {
	  private Object data;
	  private String status ;
	  private String message;
	  
	  
	public ProfileResponse(Object data, String status, String message) {
	    super();
	    this.data = data;
	    this.status = status;
	    this.message = message;
	}


	public ProfileResponse() {
	    super();
	    // TODO Auto-generated constructor stub
	}

	public Object getData() {
	    return data;
	}


	public void setData(Object data) {
	    this.data = data;
	}


	public String getStatus() {
	    return status;
	}


	public void setStatus(String status) {
	    this.status = status;
	}


	public String getMessage() {
	    return message;
	}


	public void setMessage(String message) {
	    this.message = message;
	}


	@Override
	public String toString() {
	    return "Responsedto [data=" + data + ", status=" + status + ", message=" + message + "]";
	}

	}