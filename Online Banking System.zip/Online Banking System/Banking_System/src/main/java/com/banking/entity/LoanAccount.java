package com.banking.entity;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;

@Entity
public class LoanAccount {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
private long loanId;
private Date startDate;
private Date endDate;
private int tenure;
private double rateOfInterest;
private double principalAmount;
private double monthlyPaymentEMI;
private double outstandingBalance;
private String status;

@OneToOne
private Account_Details accountdetails;

public long getLoanId() {
	return loanId;
}
public void setLoanId(long loanId) {
	this.loanId = loanId;
}
public Date getStartDate() {
	return startDate;
}
public void setStartDate(Date startDate) {
	this.startDate = startDate;
}
public Date getEndDate() {
	return endDate;
}
public void setEndDate(Date endDate) {
	this.endDate = endDate;
}
public int getTenure() {
	return tenure;
}
public void setTenure(int tenure) {
	this.tenure = tenure;
}
public double getRateOfInterest() {
	return rateOfInterest;
}
public void setRateOfInterest(double rateOfInterest) {
	this.rateOfInterest = rateOfInterest;
}
public double getPrincipalAmount() {
	return principalAmount;
}
public void setPrincipalAmount(double principalAmount) {
	this.principalAmount = principalAmount;
}
public double getMonthlyPaymentEMI() {
	return monthlyPaymentEMI;
}
public void setMonthlyPaymentEMI(double monthlyPaymentEMI) {
	this.monthlyPaymentEMI = monthlyPaymentEMI;
}
public double getOutstandingBalance() {
	return outstandingBalance;
}
public void setOutstandingBalance(double outstandingBalance) {
	this.outstandingBalance = outstandingBalance;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}

}
