package com.banking.response;

public class ResponeAccountnum {
	 private String message ;
	  private String status;
	  private long  Accountno;
	// TODO Auto-generated constructor stub

	@Override
	public String toString() {
	    return "ResponeAccountnum [message=" + message + ", status=" + status + ", Accountno=" + Accountno + "]";
	}
	public ResponeAccountnum() {
	    super();
	    // TODO Auto-generated constructor stub
	}
	public String getMessage() {
	    return message;
	}
	public void setMessage(String message) {
	    this.message = message;
	}
	public String getStatus() {
	    return status;
	}
	public void setStatus(String status) {
	    this.status = status;
	}
	public long getAccountno() {
	    return Accountno;
	}
	public void setAccountno(long accountno) {
	    Accountno = accountno;
	}
	public ResponeAccountnum(String message, String status, long accountno) {
	    super();
	    this.message = message;
	    this.status = status;
	    Accountno = accountno;
	}
	  
	}


