package com.banking.dto;

import java.sql.Date;

import org.hibernate.validator.constraints.Range;

public class Account_DetailsDto {

     private long accid;
     private long accountnumber;
     private String accounttype;
     private double balance;
     private Date created_on;
     private String IFSC;
     private String branch_name;
	public String getIFSC() {
		return IFSC;
	}
	public void setIFSC(String iFSC) {
		IFSC = iFSC;
	}
	public String getBranch_name() {
		return branch_name;
	}
	public void setBranch_name(String branch_name) {
		this.branch_name = branch_name;
	}
	public long getAccid() {
		return accid;
	}
	public void setAccid(long accid) {
		this.accid = accid;
	}
	public long getAccountnumber() {
		return accountnumber;
	}
	public void setAccountnumber(long accountnumber) {
		this.accountnumber = accountnumber;
	}
	public String getAccounttype() {
		return accounttype;
	}
	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Date getCreated_on() {
		return created_on;
	}
	public void setCreated_on(Date created_on) {
		this.created_on = created_on;
	}
	public Account_DetailsDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Account_DetailsDto(long accid, long accountnumber, String accounttype, double balance, Date created_on) {
		super();
		this.accid = accid;
		this.accountnumber = accountnumber;
		this.accounttype = accounttype;
		this.balance = balance;
		this.created_on = created_on;
		
	}
	@Override
	public String toString() {
		return "Account_DetailsDto [accid=" + accid + ", accountnumber=" + accountnumber + ", accounttype="
				+ accounttype + ", balance=" + balance + ", created_on=" + created_on +  "]";
	}
	
   


     
}