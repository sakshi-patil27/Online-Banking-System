package com.banking.Service;

import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MyTools {
    public static boolean createLog(String apiEndPoint, String plainJsonReq, String plainJsonResp, String actJsonReq,
            String actJsonResp, String fileName) {
        boolean status = false;
        String dirLocation = "/home/spatil@microproindia.com/apilogs/";
        Date dt = new Date();
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat sdf2 = new SimpleDateFormat("HH:mm:ss");
        System.out.println(sdf1.format(dt)+"T"+sdf2.format(dt));
        try {
            FileWriter fw = new FileWriter(dirLocation+ fileName+"_"+ sdf1.format(dt)+"T"+sdf2.format(dt));
            fw.write("apiEndPoint: " + apiEndPoint + "\n");
            fw.write("plainJsonReq: " + plainJsonReq + "\n");
            fw.write("plainJsonResp: " + plainJsonResp + "\n");
            fw.write("actJsonReq: " + actJsonReq + "\n");
            fw.write("actJsonResp: " + actJsonResp + "\n");
            fw.write("\t\t <<<<<<<<<<<<<<<<<<<<<<<< Log created >>>>>>>>>>>>>>>>>>>>\n");
            fw.close();
            status = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }
}
