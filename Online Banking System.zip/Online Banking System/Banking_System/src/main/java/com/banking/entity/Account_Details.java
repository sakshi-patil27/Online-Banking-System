
package com.banking.entity;

import java.sql.Date;
import java.util.List;

import org.hibernate.validator.constraints.Range;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity
public class Account_Details {
    @Id
    private long accid;
    private long accountnumber;
    private String accounttype;
    @Range(min = 2000,message="Amount should be greaterb than 2000")
    private double balance;
    
    private Date created_on;
    private String created_by;
    private Date modified_on;
    private String modified_by;
    private String IFSC;
    private String branch_name;
    
    
    @ManyToOne
    @JoinColumn(name="customer_id")
    private Customer customer;
     
    @OneToOne(mappedBy="accountdetails",cascade=CascadeType.ALL)
    private LoanAccount loanaccount;


    @OneToMany(mappedBy="accountDetails",cascade=CascadeType.ALL)
    @JsonManagedReference
    private List<CheckBook> checkBook;


    
	public long getAccid() {
		return accid;
	}


	public void setAccid(long accid) {
		this.accid = accid;
	}


	public long getAccountnumber() {
		return accountnumber;
	}


	public void setAccountnumber(long accountnumber) {
		this.accountnumber = accountnumber;
	}


	public String getAccounttype() {
		return accounttype;
	}


	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}


	public double getBalance() {
		return balance;
	}


	public void setBalance(double balance) {
		this.balance = balance;
	}


	public Date getCreated_on() {
		return created_on;
	}


	public void setCreated_on(Date created_on) {
		this.created_on = created_on;
	}


	public String getCreated_by() {
		return created_by;
	}


	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}


	public Date getModified_on() {
		return modified_on;
	}


	public void setModified_on(Date modified_on) {
		this.modified_on = modified_on;
	}


	public String getModified_by() {
		return modified_by;
	}


	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}


	public Customer getCustomer() {
		return customer;
	}


	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	


	@Override
	public String toString() {
		return "Account_Details [accid=" + accid + ", accountnumber=" + accountnumber + ", accounttype=" + accounttype
				+ ", balance=" + balance + ", created_on=" + created_on + ", created_by=" + created_by
				+ ", modified_on=" + modified_on + ", modified_by=" + modified_by + ", IFSC=" + IFSC + ", branch_name="
				+ branch_name + ", customer=" + customer + "]";
	}


	

	public Account_Details(long accid, long accountnumber, String accounttype,
			@Range(min = 2000, message = "Amount should be greaterb than 2000") double balance, Date created_on,
			String created_by, Date modified_on, String modified_by, String iFSC, String branch_name, Customer customer,
			LoanAccount loanaccount) {
		super();
		this.accid = accid;
		this.accountnumber = accountnumber;
		this.accounttype = accounttype;
		this.balance = balance;
		this.created_on = created_on;
		this.created_by = created_by;
		this.modified_on = modified_on;
		this.modified_by = modified_by;
		IFSC = iFSC;
		this.branch_name = branch_name;
		this.customer = customer;
		this.loanaccount = loanaccount;
	}


	public LoanAccount getLoanaccount() {
		return loanaccount;
	}


	public void setLoanaccount(LoanAccount loanaccount) {
		this.loanaccount = loanaccount;
	}


	public String getIFSC() {
		return IFSC;
	}


	public void setIFSC(String iFSC) {
		IFSC = iFSC;
	}


	public String getBranch_name() {
		return branch_name;
	}


	public void setBranch_name(String branch_name) {
		this.branch_name = branch_name;
	}


	public Account_Details() {
		super();
		// TODO Auto-generated constructor stub
	}

	

}



