package com.banking.Controller;

import java.security.NoSuchAlgorithmException;
import java.sql.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.banking.Service.BankService;
import com.banking.dto.Account_DetailsDto;
import com.banking.dto.CustomerDto;
import com.banking.dto.CustomerTransactionSummary;
import com.banking.entity.Account_Details;
import com.banking.entity.Bank_Staff;
import com.banking.entity.Customer;
import com.banking.entity.Transaction_Details;
import com.banking.entity.User_Master;
import com.banking.response.ActualReqResp;
import com.banking.response.ResponseForEncryAndHash;
import com.banking.response.ResponseForToken;
import com.banking.response.ResponseModel;
import com.banking.security.ClientEncrypt;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/bank")
@Tag(name="BankController",description="to perform operation on bank")
public class Bankcontroller {
	@Autowired
	private BankService bankservice;
	@Autowired
	private ClientEncrypt clientencry;

	// Add the customer
	   @Operation
	   (
	        summary="POST Operation on student"  ,
	        description ="IT is used to  save student  object in database "
	        
	    )
	@PostMapping("/addcustomer")
	public ResponseEntity addAccountCustomer(@Valid @RequestBody ActualReqResp actualreqresp,
			@RequestHeader("Authorization") String authorizationHeader) throws Exception {
		return bankservice.addAccount(authorizationHeader, actualreqresp);
		
	}


	// Login
	@PostMapping("/login")
	public ResponseEntity login(@RequestBody ActualReqResp actualreqresp) throws Exception {
		 return bankservice.login(actualreqresp);
		
	}

	// Deposit
	@PostMapping("/transaction/deposit")
	public ResponseEntity deposit(@RequestBody ActualReqResp actualreqresp,
			@RequestHeader("Authorization") String authorizationHeader) throws Exception {
		 return bankservice.deposit(actualreqresp, authorizationHeader);
		
	}

	// Withdrawal
	@PostMapping("/transaction/withdrawal")
	public ResponseEntity withdrawal(@RequestBody ActualReqResp actualreqresp, 
			@RequestHeader("Authorization") String authorizationHeader) throws Exception {
	return bankservice.withdrawal(actualreqresp, authorizationHeader);
		
	}


	

	// Get account details from the customer id_HD
	    @PostMapping("/getAccountsById")
	    public ResponseEntity<ActualReqResp> getbyid(@RequestHeader("Authorization") String authorizationHeader ,@RequestBody ActualReqResp body) throws Exception {
	        ActualReqResp response=  bankservice.getAccountDetailsbyId(body,authorizationHeader);
	        return ResponseEntity.status(HttpStatus.OK).body(response);
	    }
	    
	 // Get Balance using Account Number_HD
		@PostMapping("/getbalancebyaccnumber")
		public ResponseEntity<ActualReqResp> getbalance(@RequestHeader("Authorization") String authorizationHeader ,@RequestBody ActualReqResp body) throws Exception {
			ActualReqResp response=bankservice.getBalancebyAccountnumber(body,authorizationHeader);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}

		// Get Balance using Customer id and account type_HD
		@PostMapping("/getbalance")
		public ResponseEntity<ActualReqResp> getBalancebyCustidAndAcctype(@RequestHeader("Authorization") String authorizationHeader,@RequestBody ActualReqResp body) throws Exception{
			ActualReqResp response=bankservice.getBalancebyAccountType(body,authorizationHeader);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}

		
		
		
		
		
		
		//Get account details by id
	    @PostMapping("/getcustomerbyId")
	    public ResponseEntity getCustomerWithAccountDetails(@Valid @RequestBody ActualReqResp body, @RequestHeader("Authorization") String authorizationHeader )
	            throws Exception {
	        
	        ActualReqResp responceModel = bankservice.getCustomerWithAccountDetails(body,authorizationHeader );
	        return ResponseEntity.status(200).body(responceModel);
	    }
	    
	    
	    
	    
	    
	    //Get transaction by customer id
	    @PostMapping("/transaction/customer")
	    public ActualReqResp transaction_getby_customer_id(@RequestHeader("Authorization") String autherizationHeader,
	            @RequestBody ActualReqResp body) throws Exception {
	        ActualReqResp respModelObj = bankservice.transaction_get_by_id(autherizationHeader, body);
	        return respModelObj;
	    }

	    //Get transaction by account number
	    @PostMapping("/transaction/accountno")
	    public ActualReqResp transaction_getby_accno(@RequestHeader("Authorization") String autherizationHeader,
	            @RequestBody ActualReqResp body) throws Exception {
	        ActualReqResp respModelObj = bankservice.transaction_get_by_accno(autherizationHeader, body);
	        return respModelObj;
	    }

	    //Get all transactions
	    @GetMapping("/transaction/all")
	    public ActualReqResp transaction(@RequestHeader("Authorization") String autherizationHeader) throws Exception {
	        ActualReqResp respModelObj = bankservice.getAllTransaction(autherizationHeader);
	        return respModelObj;
	    }

	    //Get transaction by date
	    @PostMapping("/transaction/date")
	    public ActualReqResp transactionByDate(@RequestHeader("Authorization") String autherizationHeader,
	            @RequestBody ActualReqResp body) throws Exception {
	        ActualReqResp respModelObj = bankservice.getTransactionByDate(autherizationHeader, body);
	        return respModelObj;
	    }

	    //Get transaction between given dates
	    @PostMapping("/transaction/datebetween")
	    public ActualReqResp transactionByDateBetween(@RequestHeader("Authorization") String autherizationHeader,
	            @RequestBody ActualReqResp body) throws Exception {
	        ActualReqResp respModelObj = bankservice.getTransactionBetweenDate(autherizationHeader, body);
	        return respModelObj;
	    }
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	  //Request Check Book input: { "accountnumber":"587564749902",  "leaves":"10","address":"Trimurti nagar" }
	    @PostMapping("/requestCheckBook")
	    public ResponseEntity requestCheckBook(@Valid @RequestHeader("Authorization") String token, @RequestBody ActualReqResp body) throws JsonMappingException, JsonProcessingException, NoSuchAlgorithmException {
	        return bankservice.requestCheckBook(body,token);
	    }

	    //Decrypt API for Request Check Book API
	    @PostMapping("/decryptRequestCheckBook")
	    public ResponseEntity decryptRequestCheckBook(@Valid @RequestBody ActualReqResp body) throws JsonMappingException, JsonProcessingException, NoSuchAlgorithmException {
	        return bankservice.decryptRequestCheckBook(body);
	    }
	    
	    
	    
	  //View List of Requested Check Books Staff 
	    @PostMapping("/ListOfRequestedCheckBook")
	    public ResponseEntity ListOfRequestedCheckBook(@Valid @RequestHeader("Authorization") String token,@RequestBody ActualReqResp body ) throws JsonMappingException, JsonProcessingException, NoSuchAlgorithmException {
	        return bankservice.ListOfRequestedCheckBook(body,token);
	    }


	    
	    
	    
	    
	    
	    
	    
	    
	 // TO Create a bank account and genrate a Account number  
	    @PostMapping(value = "/AccountDetail/CreateAccount", consumes = "application/json")
	    public ResponseEntity newcustomer( @RequestBody ActualReqResp Ad,@RequestHeader("Authorization") String authorizationHeader) throws Exception  {
	    ActualReqResp response =bankservice.Details(Ad,authorizationHeader);
	        return ResponseEntity.status(HttpStatus.OK).body(response) ;
	    }



	// to transfer a Money from one account to another 
	    @PostMapping(value = "/transfer")
	    public ResponseEntity  moneytransfer(   @RequestBody ActualReqResp Ad,@RequestHeader("Authorization") String authorizationHeader) throws Exception 
	    {
	        ActualReqResp response = bankservice.transfer(Ad,authorizationHeader) ;
	        return ResponseEntity.status(HttpStatus.OK).body(response) ;
	        
	    }


	    
	    
	    
	    @PostMapping(value = "/getencryptedstaff", consumes = "application/json")
	    public ResponseEntity<ActualReqResp> getEncryptedStaffById(@RequestHeader("Authorization") String authorizationHeader,
	            @RequestBody ActualReqResp body) throws NoSuchAlgorithmException, JsonProcessingException {

	        ActualReqResp encryptedStaffById = bankservice.getEncryptedStaffById(authorizationHeader, body);
	        return ResponseEntity.status(HttpStatus.OK).body(encryptedStaffById);

	    }

	    @PutMapping("/updateStaff")
	    public ResponseEntity<ActualReqResp> updateStaff(@RequestHeader("Authorization") String authorizationHeader,@RequestBody ActualReqResp body) throws JsonMappingException, JsonProcessingException {
	        ActualReqResp ar  = bankservice.updateStaff(authorizationHeader,body);
	        return ResponseEntity.status(HttpStatus.OK).body(ar);


	    }
	    
	    @PutMapping("/updateCustomer")
	    public ResponseEntity<ActualReqResp> updateCustomer(@RequestBody ActualReqResp body) throws JsonMappingException, JsonProcessingException {
	        ActualReqResp ar  = bankservice.updateCustomer(body);
	        return ResponseEntity.status(HttpStatus.OK).body(ar);


	    }

	    @DeleteMapping("/deleteStaff")
	    public ResponseEntity<ActualReqResp> deleteStaff(@RequestBody ActualReqResp body)
	            throws JsonMappingException, JsonProcessingException, NoSuchAlgorithmException {
	        
	            ActualReqResp ar = bankservice.deleteStaff(body);
	            
	            return ResponseEntity.status(HttpStatus.OK).body(ar);
	    }
	    
	    @DeleteMapping("/deleteCustomer")
	    public ResponseEntity<ActualReqResp> deleteCustomer(@RequestBody ActualReqResp body)
	            throws JsonMappingException, JsonProcessingException, NoSuchAlgorithmException {
	        
	            ActualReqResp ar = bankservice.deleteStaff(body);
	            
	            return ResponseEntity.status(HttpStatus.OK).body(ar);
	    }
	    
	    
	    
	    
	    
	   
}
