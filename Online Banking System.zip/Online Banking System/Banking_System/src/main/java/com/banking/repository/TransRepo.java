package com.banking.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.banking.entity.Customer;
import com.banking.entity.Transaction_Details;
import com.banking.entity.User_Master;

@Repository
public interface TransRepo  extends JpaRepository<Transaction_Details,Long> {
	List<Transaction_Details> findByAccountnumber(long accno);
	List<Transaction_Details> findByTransactiondate(Date transaction_date);
	List<Transaction_Details> findByTransactiondateBetween(Date startDate,Date endDate);
	
}
