package com.banking.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.banking.entity.Customer;

public interface BankdaoRepo extends CrudRepository<Customer, Long> {

//	Customer findByidAndStatus(long customer_id, String status);
	
	@Query("SELECT a FROM Customer a WHERE a.customer_id = :id AND a.Status= :status")
	public Customer findByidAndStatus(@Param("id") long id,@Param("status") String status);

}
