package com.banking.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.banking.entity.Account_Details;
import com.banking.entity.Customer;
@Repository
public interface AccountDetailsRepository extends JpaRepository<Account_Details,Long>{

//	Optional<Account_Details> findByCustomerId(long customer_id);
      
   Account_Details findByAccountnumber(long accountNumber);
   
   @Query("SELECT a FROM Account_Details a Join a.customer c WHERE c.customer_id = :customer_id")
   List<Account_Details> findByCustomerId(@Param("customer_id") Long customer_id);
   
   Long countByCustomerAndAccounttype(Customer customer, String type);
   
   List<Account_Details> findByAccounttype(String accounttype);
   
   @Query("SELECT a FROM Account_Details a WHERE a.accountnumber = :accountNumber")
   public Account_Details findByaccountnumber(@Param("accountNumber") long accountnumber);
   
   @Query("SELECT a FROM Account_Details a Join a.customer c WHERE c.customer_id = :customer_id AND a.accounttype = :accountType")
   public Account_Details findByCustidAndAccType(@Param("customer_id") long customer_id,@Param("accountType") String accounttype);
}

