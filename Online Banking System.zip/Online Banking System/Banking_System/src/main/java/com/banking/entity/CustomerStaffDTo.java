package com.banking.entity;

import java.sql.Date;

import org.hibernate.validator.constraints.Range;

import com.banking.validation.ValidateDob;

import jakarta.persistence.Column;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;


public class CustomerStaffDTo {
private long customer_id;
	
	@NotEmpty(message = "Name must not be null or empty")
    @Pattern(regexp = "^[A-Z][a-z]*$", message = "Employee name must be in capital case .")
    private String fname;
    @NotEmpty(message = "Name must not be null or empty")
    @Pattern(regexp = "^[A-Z][a-z]*$", message = "Employee name must be in capital case .")
    private String lname;
    @NotNull
    @ValidateDob
    private Date dob;
    @NotEmpty(message = "Email must not be null or empty")
    @Email(message = "Not a valid email")
    private String email;
    private String address;
    @NotNull(message = "Phone nuber must not be null or empty")
    @Range(min = 1000000000L, max = 9999999999L , message = "Phone number should be 10 digits and should not start with zero.")
    private long phone_no;
    @NotEmpty(message = "Password Should not empty")
    @Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[#$@!%&*?])[A-Za-z\\d#$@!%&*?]{8,}$", message = "Password must have "
            + "    Min 1 uppercase letter."
            + "    Min 1 lowercase letter."
            + "    Min 1 special character."
            + "    Min 1 number."
            + "    Min 8 characters.")
	private String password;
    private Date created_on;
    private String created_by;
    private Date modified_on;
    private String modified_by;
    @NotNull(message = "Pincode must not be null or empty")
    @Range(min = 100000L, max = 999999L , message = "Pincode should be 6 digits and should not start with zero.")
    private long pincode;
    @Column(nullable=false,columnDefinition="varchar(25) default 'y'")
    private String Status="y";
    @NotEmpty(message = "Pancard number must not be null or empty")
    @Pattern(regexp = "^[A-Z]{5}[0-9]{4}[A-Z]{1}", message = "Pancard number name must be in capital case .")
    private String pancard;
    private long staff_id;
	public long getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(long customer_id) {
		this.customer_id = customer_id;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(long phone_no) {
		this.phone_no = phone_no;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Date getCreated_on() {
		return created_on;
	}
	public void setCreated_on(Date created_on) {
		this.created_on = created_on;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public Date getModified_on() {
		return modified_on;
	}
	public void setModified_on(Date modified_on) {
		this.modified_on = modified_on;
	}
	public String getModified_by() {
		return modified_by;
	}
	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}
	public long getPincode() {
		return pincode;
	}
	public void setPincode(long pincode) {
		this.pincode = pincode;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	public long getStaff_id() {
		return staff_id;
	}
	public void setStaff_id(long staff_id) {
		this.staff_id = staff_id;
	}
	public CustomerStaffDTo(long customer_id,
			@NotEmpty(message = "Name must not be null or empty") @Pattern(regexp = "^[A-Z][a-z]*$", message = "Employee name must be in capital case .") String fname,
			@NotEmpty(message = "Name must not be null or empty") @Pattern(regexp = "^[A-Z][a-z]*$", message = "Employee name must be in capital case .") String lname, Date dob,
			@NotEmpty(message = "Email must not be null or empty") @Email(message = "Not a valid email") String email,
			String address,
			@NotNull(message = "Phone nuber must not be null or empty") @Range(min = 1000000000, max = 99999999, message = "Phone number should be 10 digits and should not start with zero.") long phone_no,
			@NotEmpty(message = "Password Should not empty") @Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[#$@!%&*?])[A-Za-z\\d#$@!%&*?]{8,}$", message = "Password must have     Min 1 uppercase letter.    Min 1 lowercase letter.    Min 1 special character.    Min 1 number.    Min 8 characters.") String password,
			Date created_on, String created_by, Date modified_on, String modified_by,
			@NotNull(message = "Pincode must not be null or empty") @Range(min = 100000, max = 999999, message = "Pincode should be 6 digits and should not start with zero.") long pincode,
			String status,
			@NotEmpty(message = "Pancard number must not be null or empty") @Pattern(regexp = "^[A-Z]{5}[0-9]{4}[A-Z]{1}", message = "Pancard number name must be in capital case .") String pancard,
			long staff_id) {
		super();
		this.customer_id = customer_id;
		this.fname = fname;
		this.lname = lname;
		this.dob = dob;
		this.email = email;
		this.address = address;
		this.phone_no = phone_no;
		this.password = password;
		this.pincode = pincode;
		Status = status;
		this.pancard = pancard;
		this.staff_id = staff_id;
	}
	public CustomerStaffDTo() {
		super();
		// TODO Auto-generated constructor stub
	}
	
    
    
}

