package com.banking.security;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.KeySpec;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.banking.entity.Account_Details;
import com.banking.entity.Bank_Staff;
import com.banking.entity.Customer;
import com.banking.entity.CustomerStaffDTo;
import com.banking.entity.TransactionAndCustomerDto;
import com.banking.entity.Transaction_Details;
import com.banking.entity.User_Master;
import com.banking.response.ActualReqResp;
import com.banking.response.DateBetween;
import com.banking.response.ResponseForEncryAndHash;
import com.banking.response.ResponseForToken;
import com.banking.response.ResponseModel;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class ClientEncrypt {



	public String encryptandhash(CustomerStaffDTo body) throws Exception {
        System.out.println(body);
		ObjectMapper objectmapper = new ObjectMapper();
		String jsonString = objectmapper.writeValueAsString(body);
		String encrypted_String = encrypt(jsonString);
		String hash = createSHAHash(jsonString); 
		String encryptedAndHashData = encrypted_String + "Hash data:" + hash;
		return encryptedAndHashData;
	}

	public String encryptandhashforlogin(User_Master um) throws Exception {
		ObjectMapper objectmapper = new ObjectMapper();
		String jsonString = objectmapper.writeValueAsString(um);
		String encrypted_String = encrypt(jsonString);
		String hash = createSHAHash(jsonString); // createSHAHash(jsonString);
		String encryptedAndHashData = encrypted_String + "Hash data:  " + hash;
		return encryptedAndHashData;
	}

	public String encryptandhashforTransaction(TransactionAndCustomerDto td) throws Exception {
		ObjectMapper objectmapper = new ObjectMapper();
		String jsonString = objectmapper.writeValueAsString(td);
		String encrypted_String = encrypt(jsonString);
		String hash = createSHAHash(jsonString);
		String encryptedAndHashData = encrypted_String + "Hash data:  " + hash;
		return encryptedAndHashData;
	}

	public ActualReqResp encryptandhashforResponseModel(ResponseModel rm) throws Exception {

		ObjectMapper objectmapper = new ObjectMapper();
		String jsonString = objectmapper.writeValueAsString(rm);
		String encrypted_String = encrypt(jsonString);
		String hash = createSHAHash(jsonString); // createSHAHash(jsonString);
		String encryptedAndHashData = encrypted_String + "Hash data:  " + hash;
		return new ActualReqResp(encrypted_String, hash);
	}

	public ActualReqResp encryptandhashforResponseModelForToken(ResponseForToken rt) throws Exception {

		ObjectMapper objectmapper = new ObjectMapper();
		String jsonString = objectmapper.writeValueAsString(rt);
		String encrypted_String = encrypt(jsonString);
		String hash = createSHAHash(jsonString); // createSHAHash(jsonString);
		String encryptedAndHashData = encrypted_String + "Hash data:  " + hash;
		return new ActualReqResp(encrypted_String, hash);
	}


	public String encryptedid(String body) throws Exception {
		String encrypted_String = encrypt(body);
		String hash = createSHAHash(body); // createSHAHash(jsonString);
		String encryptedAndHashData = encrypted_String + "Hash data:  " + hash;
		return encryptedAndHashData;
	}

	public static String getCheckSumValue(String data, String ChecksumFlag) {
		if (ChecksumFlag.equals("SHA512"))
			return DigestUtils.sha512Hex(data);
		else
			return null;
	}

	public static String decrypt(String strToDecrypt) {
		try {

			// Default byte array
			byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
			// Create IvParameterSpec object and assign with
			// constructor
			IvParameterSpec ivspec = new IvParameterSpec(iv);

			// Create SecretKeyFactory Object
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

			// Create KeySpec object and assign with
			// constructor
			KeySpec spec = new PBEKeySpec(SECRET_KEY.toCharArray(), SALT.getBytes(), 65536, 256);
			SecretKey tmp = factory.generateSecret(spec);
			SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");

			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
			cipher.init(Cipher.DECRYPT_MODE, secretKey, ivspec);
			// Return decrypted string
			return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
		} catch (Exception e) {
			System.out.println("Error while decrypting: " + e.toString());
		}
		return null;
	}



	private static final String SECRET_KEY = "my_super_secret_key_ho_ho_ho";

	private static final String SALT = "ssshhhhhhhhhhh!!!!";

	// This method use to encrypt to string
	public static String encrypt(String strToEncrypt) {
		try {

			// Create default byte array
			byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
			IvParameterSpec ivspec = new IvParameterSpec(iv);

			// Create SecretKeyFactory object
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

			// Create KeySpec object and assign with
			// constructor
			KeySpec spec = new PBEKeySpec(SECRET_KEY.toCharArray(), SALT.getBytes(), 65536, 256);
			SecretKey tmp = factory.generateSecret(spec);
			SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");

			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivspec);
			// Return encrypted string
			return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes(StandardCharsets.UTF_8)));
		} catch (Exception e) {
			System.out.println("Error while encrypting: " + e.toString());
		}
		return null;
	}

	public static String createSHAHash(String plaintext) throws NoSuchAlgorithmException {
		MessageDigest md = MessageDigest.getInstance("SHA-256");
		byte[] messageDigest = md.digest(plaintext.getBytes(StandardCharsets.UTF_8));
		return new String(Base64.getEncoder().encodeToString(messageDigest));
	}
	
	
	
	
	
	public String encryptandhash(Customer body) throws Exception {
        System.out.println(body);
        ObjectMapper objectmapper = new ObjectMapper();
        String jsonString = objectmapper.writeValueAsString(body);
        String encrypted_String = encrypt(jsonString);
        String hash = createSHAHash(jsonString);
        String encryptedAndHashData = encrypted_String + "Hash data:" + hash;
        return encryptedAndHashData;
    }

    public String encryptandhashforTransactionData(Transaction_Details um) throws Exception {
        ObjectMapper objectmapper = new ObjectMapper();
        String jsonString = objectmapper.writeValueAsString(um);
        String encrypted_String = encrypt(jsonString);
        String hash = createSHAHash(jsonString); // createSHAHash(jsonString);
        String encryptedAndHashData = encrypted_String + "Hash data:  " + hash;
        return encryptedAndHashData;
    }

    public String encryptandhashforAccountDetails(Account_Details td) throws Exception {
        ObjectMapper objectmapper = new ObjectMapper();
        String jsonString = objectmapper.writeValueAsString(td);
        String encrypted_String = encrypt(jsonString);
        String hash = createSHAHash(jsonString);
        String encryptedAndHashData = encrypted_String + "Hash data:  " + hash;
        return encryptedAndHashData;
    }

    public String encryptandhashforDateBetween(DateBetween rm) throws Exception {
        ObjectMapper objectmapper = new ObjectMapper();
        String jsonString = objectmapper.writeValueAsString(rm);
        String encrypted_String = encrypt(jsonString);
        String hash = createSHAHash(jsonString); // createSHAHash(jsonString);
        String encryptedAndHashData = encrypted_String + "Hash data:  " + hash;
        return encryptedAndHashData;
    }
}


