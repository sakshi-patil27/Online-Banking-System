package com.banking.entity;

import java.sql.Date;

import org.hibernate.validator.constraints.Range;

import com.banking.validation.ValidateDob;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
@Entity
public class Bank_Staff {
	    @Id
	    @GeneratedValue(strategy=GenerationType.IDENTITY)
	    private long Staff_id;
	    @NotEmpty(message = "Name must not be null or empty")
	    @Pattern(regexp = "^[A-Z][a-z]*$", message = "Employee name must be in capital case .")
	    private String fname;
	    @NotEmpty(message = "Name must not be null or empty")
	    @Pattern(regexp = "^[A-Z][a-z]*$", message = "Employee name must be in capital case .")
	    private String lname;
	    @NotNull
	    @ValidateDob
	    private Date dob;
	    @NotEmpty(message = "Gender must not be null or empty")
	    @Pattern(regexp = "^[A-Z][a-z]*$", message = "Gender must be in capital case .")
	    private String gender;
	    @NotEmpty(message = "Email must not be null or empty")
	    @Email(message = "Not a valid email")
	    private String email;
	    private String address;
	    @NotNull(message = "Phone nuber must not be null or empty")
	    @Range(min = 1000000000L, max = 9999999999L , message = "Phone number should be 10 digits and should not start with zero.")
	    private long phone_no;
	    @NotNull
	    private Date joining_Date;
	    @NotEmpty(message = "Password Should not empty")
	    @Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[#$@!%&*?])[A-Za-z\\d#$@!%&*?]{8,}$", message = "Password must have "
	            + "    Min 1 uppercase letter."
	            + "    Min 1 lowercase letter."
	            + "    Min 1 special character."
	            + "    Min 1 number."
	            + "    Min 8 characters.")
		private String password;
	    @Column(nullable=false,columnDefinition="varchar(25) default 'y'")
	    private String Status="y";
	    @NotEmpty(message = "Pancard number must not be null or empty")
	    @Pattern(regexp = "^[A-Z]{5}[0-9]{4}[A-Z]{1}", message = "Pancard number name must be in capital case .")
	    private String pancard;
	    private Date created_on;
	    private String created_by;
	    private Date modified_on;
	    private String modified_by;
	    
	    @OneToOne(mappedBy="bankstaff",cascade=CascadeType.ALL)
		private User_Master usermaster;

	
	public long getStaff_id() {
		return Staff_id;
	}

	public void setStaff_id(long staff_id) {
		Staff_id = staff_id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public User_Master getUsermaster() {
		return usermaster;
	}

	public void setUsermaster(User_Master usermaster) {
		this.usermaster = usermaster;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getPhone_no() {
		return phone_no;
	}

	public void setPhone_no(long phone_no) {
		this.phone_no = phone_no;
	}

	public Date getJoining_Date() {
		return joining_Date;
	}

	public void setJoining_Date(Date joining_Date) {
		this.joining_Date = joining_Date;
	}


	

	


	@Override
	public String toString() {
		return "Bank_Staff [Staff_id=" + Staff_id + ", fname=" + fname + ", lname=" + lname + ", dob=" + dob
				+ ", gender=" + gender + ", email=" + email + ", address=" + address + ", phone_no=" + phone_no
				+ ", joining_Date=" + joining_Date + ", password=" + password + ", Status=" + Status + ", pancard="
				+ pancard + ", created_on=" + created_on + ", created_by=" + created_by + ", modified_on=" + modified_on
				+ ", modified_by=" + modified_by + ", usermaster=" + usermaster + "]";
	}

	public Bank_Staff(long staff_id,
			@NotEmpty(message = "Name must not be null or empty") @Pattern(regexp = "^[A-Z][a-z]*$", message = "Employee name must be in capital case .") String fname,
			@NotEmpty(message = "Name must not be null or empty") @Pattern(regexp = "^[A-Z][a-z]*$", message = "Employee name must be in capital case .") String lname,
			@NotNull Date dob,
			@NotEmpty(message = "Gender must not be null or empty") @Pattern(regexp = "^[A-Z][a-z]*$", message = "Gender must be in capital case .") String gender,
			@NotEmpty(message = "Email must not be null or empty") @Email(message = "Not a valid email") String email,
			String address,
			@NotNull(message = "Phone nuber must not be null or empty") @Range(min = 1000000000, max = 99999999, message = "Phone number should be 10 digits and should not start with zero.") long phone_no,
			@NotNull Date joining_Date,
			@NotEmpty(message = "Password Should not empty") @Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[#$@!%&*?])[A-Za-z\\d#$@!%&*?]{8,}$", message = "Password must have     Min 1 uppercase letter.    Min 1 lowercase letter.    Min 1 special character.    Min 1 number.    Min 8 characters.") String password,
			String status, String pancard, Date created_on, String created_by, Date modified_on, String modified_by,
			User_Master usermaster) {
		super();
		Staff_id = staff_id;
		this.fname = fname;
		this.lname = lname;
		this.dob = dob;
		this.gender = gender;
		this.email = email;
		this.address = address;
		this.phone_no = phone_no;
		this.joining_Date = joining_Date;
		this.password = password;
		Status = status;
		this.pancard = pancard;
		this.created_on = created_on;
		this.created_by = created_by;
		this.modified_on = modified_on;
		this.modified_by = modified_by;
		this.usermaster = usermaster;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public Date getCreated_on() {
		return created_on;
	}

	public void setCreated_on(Date created_on) {
		this.created_on = created_on;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public Date getModified_on() {
		return modified_on;
	}

	public void setModified_on(Date modified_on) {
		this.modified_on = modified_on;
	}

	public String getModified_by() {
		return modified_by;
	}

	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}

	public Bank_Staff() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getPancard() {
		return pancard;
	}

	public void setPancard(String pancard) {
		this.pancard = pancard;
	}

	

	
	
	 
}
