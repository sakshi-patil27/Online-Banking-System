package com.banking.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class pincode {
      
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long refid;
    
    
    private long pincode;
    
    private String Branch_name;
    
    private String IFSC;

    public long getPincode() {
        return pincode;
    }

    public void setPincode(long pincode) {
        this.pincode = pincode;
    }

    public String getBranch_name() {
        return Branch_name;
    }

    public void setBranch_name(String branch_name) {
        Branch_name = branch_name;
    }

    public String getIFSC() {
        return IFSC;
    }

    public void setIFSC(String iFSC) {
        IFSC = iFSC;
    }

    public pincode() {
        super();
        // TODO Auto-generated constructor stub
    }

    public long getRefid() {
        return refid;
    }

    public void setRefid(long refid) {
        this.refid = refid;
    }

    public pincode(long refid, long pincode, String branch_name, String iFSC) {
        super();
        this.refid = refid;
        this.pincode = pincode;
        Branch_name = branch_name;
        IFSC = iFSC;
    }

    @Override
    public String toString() {
        return "pincode [refid=" + refid + ", pincode=" + pincode + ", Branch_name=" + Branch_name + ", IFSC=" + IFSC
                + "]";
    }

    
    
    
}

