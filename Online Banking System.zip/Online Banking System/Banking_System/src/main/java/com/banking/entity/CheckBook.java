package com.banking.entity;

import java.sql.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

@Entity
public class CheckBook {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long checkBookId;
    @NotNull
    private int leaves;
    @NotEmpty
    private String address;
    @NotEmpty
    private String referenceNo;
    @NotEmpty
    @Column(columnDefinition = "varchar(3) default 'Y'")
    @Pattern(regexp = "^(Y|N|y|n){1}$", message = "status can be Y or N")
    private String status;
    private long accountnumber;
    private Date created_on;
    private String created_by;
    private Date modified_on;
    private String modified_by;
   
    @ManyToOne
    @JoinColumn(name="accid")
    @JsonBackReference
    private Account_Details accountDetails;

    public long getCheckBookId() {
        return checkBookId;
    }

    public void setCheckBookId(long checkBookId) {
        this.checkBookId = checkBookId;
    }

    public int getLeaves() {
        return leaves;
    }

    public void setLeaves(int leaves) {
        this.leaves = leaves;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getReferenceNo() {
        return referenceNo;
    }

    public void setReferenceNo(String referenceNo) {
        this.referenceNo = referenceNo;
    }

    public long getAccountnumber() {
        return accountnumber;
    }

    public void setAccountnumber(long accountnumber) {
        this.accountnumber = accountnumber;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getCreated_on() {
        return created_on;
    }

    public void setCreated_on(Date created_on) {
        this.created_on = created_on;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public Date getModified_on() {
        return modified_on;
    }

    public void setModified_on(Date modified_on) {
        this.modified_on = modified_on;
    }

    public String getModified_by() {
        return modified_by;
    }

    public void setModified_by(String modified_by) {
        this.modified_by = modified_by;
    }

    public Account_Details getAccountDetails() {
        return accountDetails;
    }

    public void setAccountDetails(Account_Details accountDetails) {
        this.accountDetails = accountDetails;
    }

    @Override
    public String toString() {
        return "CheckBook [checkBookId=" + checkBookId + ", leaves=" + leaves + ", address=" + address
                + ", referenceNo=" + referenceNo + ", accountnumber=" + accountnumber + ", status=" + status
                + ", created_on=" + created_on + ", created_by=" + created_by + ", modified_on=" + modified_on
                + ", modified_by=" + modified_by + ", accountDetails=" + accountDetails + "]";
    }

    public CheckBook(long checkBookId, @NotNull int leaves, @NotEmpty String address, @NotEmpty String referenceNo,
            @NotEmpty @Pattern(regexp = "^(Y|N|n|y){1}$", message = "status can be Y or N") long accountnumber,
            String status, Date created_on, String created_by, Date modified_on, String modified_by,
            Account_Details accountDetails) {
        super();
        this.checkBookId = checkBookId;
        this.leaves = leaves;
        this.address = address;
        this.referenceNo = referenceNo;
        this.accountnumber = accountnumber;
        this.status = status;
        this.created_on = created_on;
        this.created_by = created_by;
        this.modified_on = modified_on;
        this.modified_by = modified_by;
        this.accountDetails = accountDetails;
    }

    public CheckBook() {
        super();
        // TODO Auto-generated constructor stub
    }

   
   
}
