package com.banking.entity;

import java.sql.*;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Transaction_Details {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long transaction_id;

	private String transactiontype;

	public Transaction_Details() {
		super();
	}

	private long amount;
	private Date transactiondate;
	private long accountnumber;
  //private long customer_id;

	private String created_by;
	private Date created_on;
	
	@ManyToOne
	@JoinColumn(name = "customer_id")
	@JsonBackReference
	private Customer customer;

	public long getTransaction_id() {
		return transaction_id;
	}

	public void setTransaction_id(long transaction_id) {
		this.transaction_id = transaction_id;
	}

	public String getTransactiontype() {
		return transactiontype;
	}

	public void setTransactiontype(String transactiontype) {
		this.transactiontype = transactiontype;
	}

	public long getAmount() {
		return amount;
	}

	public void setAmount(long amount) {
		this.amount = amount;
	}

	public Date getTransactiondate() {
		return transactiondate;
	}

	public void setTransactiondate(Date transactiondate) {
		this.transactiondate = transactiondate;
	}

	public long getAccountnumber() {
		return accountnumber;
	}

	public void setAccountnumber(long accountnumber) {
		this.accountnumber = accountnumber;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Date getCreated_on() {
		return created_on;
	}

	public void setCreated_on(Date created_on) {
		this.created_on = created_on;
	}

	public Transaction_Details(long transaction_id, String transactiontype, long amount, Date transactiondate,
			long accountnumber, String created_by, Date created_on, Customer customer) {
		super();
		this.transaction_id = transaction_id;
		this.transactiontype = transactiontype;
		this.amount = amount;
		this.transactiondate = transactiondate;
		this.accountnumber = accountnumber;
		this.created_by = created_by;
		this.created_on = created_on;
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "Transaction_Details [transaction_id=" + transaction_id + ", transactiontype=" + transactiontype
				+ ", amount=" + amount + ", transactiondate=" + transactiondate + ", accountnumber=" + accountnumber
				+ ", created_by=" + created_by + ", customer=" + customer + "]";
	}

}
