package com.banking.response;

import java.util.List;

import com.banking.dto.Account_DetailsDto;

public class Responsemodel1 {
    private String message;
    private List<Account_DetailsDto> data;
    private String status;
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public List<Account_DetailsDto> getData() {
        return data;
    }
    public void setData(List<Account_DetailsDto> data) {
        this.data = data;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public Responsemodel1(String message, List<Account_DetailsDto> data, String status) {
        super();
        this.message = message;
        this.data = data;
        this.status = status;
    }
    public Responsemodel1() {
        super();
        // TODO Auto-generated constructor stub
    }
    
}