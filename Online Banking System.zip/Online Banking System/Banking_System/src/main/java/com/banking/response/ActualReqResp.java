package com.banking.response;


import com.fasterxml.jackson.annotation.JsonProperty;

public class ActualReqResp {
//    @JsonProperty("encrypt")
	private String encrypt;
	private String hash;

	public ActualReqResp(String encrypt, String hash) {
		super();
		this.encrypt = encrypt;
		this.hash = hash;
	}

	@Override
	public String toString() {
		return "ActualPayLoad [encrypt=" + encrypt + ", hash=" + hash +"]";
	}

	public String getEncrypt() {
		return encrypt;
	}
	public void setEncrypt(String encrypt) {
		this.encrypt = encrypt;
	}
	public String getHash() {
		return hash;
	}
	public void setHash(String hash) {
		this.hash = hash;
	}
	
}
