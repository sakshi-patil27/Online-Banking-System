package com.banking.repository;

import org.springframework.data.repository.CrudRepository;

import com.banking.entity.Bank_Staff;

public interface BankStaffRepo extends CrudRepository<Bank_Staff,Long>{
	

}
