package com.banking.Controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.banking.entity.Account_Details;
import com.banking.entity.Bank_Staff;
import com.banking.entity.Customer;
import com.banking.entity.CustomerStaffDTo;
import com.banking.entity.TransactionAndCustomerDto;
import com.banking.entity.Transaction_Details;
import com.banking.entity.User_Master;
import com.banking.response.ActualReqResp;
import com.banking.response.DateBetween;
import com.banking.security.ClientEncrypt;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.websocket.ClientEndpoint;

@RestController
@RequestMapping("/encrypt")
public class ClientController {

	@Autowired
	private ClientEncrypt e;
	
	
	@PostMapping("/encryptData")
	public String getEncryptedCode(@RequestBody CustomerStaffDTo body)  {
		String encryptedData=null;
		try {
			encryptedData = e.encryptandhash(body);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		System.out.println("Encrypted Data: " + encryptedData);

		return encryptedData;
	}


	
	@PostMapping("/encryptLoginData")
	public String getEncryptedLogin(@RequestBody User_Master body)  {
		String encryptedData=null;
		try {
			encryptedData = e.encryptandhashforlogin(body);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		System.out.println("Encrypted Data: " + encryptedData);

		return encryptedData;
	}
	
	@PostMapping("/encryptTransactionDtoData")
	public String getEncryptedTransaction(@RequestBody TransactionAndCustomerDto body)  {
		String encryptedData=null;
		try {
			encryptedData = e.encryptandhashforTransaction(body);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		System.out.println("Encrypted Data: " + encryptedData);

		return encryptedData;
	}
	
	@PostMapping("/decrypt")
	public String getdecryptedTransaction(@RequestBody ActualReqResp body)  {
		String decryptedData=null;
		try {
			decryptedData = e.decrypt(body.getEncrypt());
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		System.out.println("Encrypted Data: " + decryptedData);

		return decryptedData;
	}
	
	
	


@PostMapping("/encryptTransactionDetailsData")
    public String getEncryptedLogin(@RequestBody Transaction_Details body)  {
        String encryptedData=null;
        try {
            encryptedData = e.encryptandhashforTransactionData(body);
        } catch (Exception e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }

        System.out.println("Encrypted Data: " + encryptedData);

        return encryptedData;
    }
  @PostMapping("/encryptDateBetweenData")
    public String getEncryptedDateBetween(@RequestBody DateBetween body)  {
        String encryptedData=null;
        try {
            encryptedData = e.encryptandhashforDateBetween(body);
        } catch (Exception e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }

        System.out.println("Encrypted Data: " + encryptedData);

        return encryptedData;
    }
   
 @PostMapping("/encryptAccountDetailsData")
    public String getEncryptedTransaction(@RequestBody Account_Details body)  {
        String encryptedData=null;
        try {
            encryptedData = e.encryptandhashforAccountDetails(body);
        } catch (Exception e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }

        System.out.println("Encrypted Data: " + encryptedData);

        return encryptedData;
    }


}
