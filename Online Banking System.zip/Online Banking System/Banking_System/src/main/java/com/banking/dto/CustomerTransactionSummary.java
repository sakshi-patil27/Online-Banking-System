package com.banking.dto;

import java.sql.Date;
import java.util.List;

public class CustomerTransactionSummary {
	    private Long customerId;
	    private String customerName;
	    private String customerEmail;
	    private List<TransactionDetail> transactions;

	    public Long getCustomerId() {
			return customerId;
		}
	    public void setCustomerId(Long customerId) {
			this.customerId = customerId;
		}
		public String getCustomerName() {
			return customerName;
		}
		public void setCustomerName(String customerName) {
			this.customerName = customerName;
		}
		public String getCustomerEmail() {
			return customerEmail;
		}
		public void setCustomerEmail(String customerEmail) {
			this.customerEmail = customerEmail;
		}



		public List<TransactionDetail> getTransactions() {
			return transactions;
		}



		public void setTransactions(List<TransactionDetail> transactions) {
			this.transactions = transactions;
		}



		public static class TransactionDetail {
	        private long transaction_id;
	        private String transaction_type;
	        private long amount;
	        private Date transaction_date;
			public long getTransaction_id() {
				return transaction_id;
			}
			public void setTransaction_id(long transaction_id) {
				this.transaction_id = transaction_id;
			}
			public String getTransaction_type() {
				return transaction_type;
			}
			public void setTransaction_type(String transaction_type) {
				this.transaction_type = transaction_type;
			}
			public long getAmount() {
				return amount;
			}
			public void setAmount(long amount) {
				this.amount = amount;
			}
			public Date getTransaction_date() {
				return transaction_date;
			}
			public void setTransaction_date(Date transaction_date) {
				this.transaction_date = transaction_date;
			}
	        
	        
	    }
	}

