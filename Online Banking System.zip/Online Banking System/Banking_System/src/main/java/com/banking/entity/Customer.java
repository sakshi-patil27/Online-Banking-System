package com.banking.entity;

import java.sql.Date;
import java.util.List;

import org.hibernate.validator.constraints.Range;

import com.banking.validation.ValidateDob;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long customer_id;
	
	@NotEmpty(message = "Name must not be null or empty")
    @Pattern(regexp = "^[A-Z][a-z]*$", message = "Employee name must be in capital case .")
    private String fname;
    @NotEmpty(message = "Name must not be null or empty")
    @Pattern(regexp = "^[A-Z][a-z]*$", message = "Employee name must be in capital case .")
    private String lname;
    @NotNull
    @ValidateDob
    private Date dob;
    @NotEmpty(message = "Email must not be null or empty")
    @Email(message = "Not a valid email")
    private String email;
    private String address;
    @NotNull(message = "Phone nuber must not be null or empty")
    @Range(min = 1000000000L, max = 9999999999L , message = "Phone number should be 10 digits and should not start with zero.")
    private long phone_no;
    @NotEmpty(message = "Password Should not empty")
    @Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[#$@!%&*?])[A-Za-z\\d#$@!%&*?]{8,}$", message = "Password must have "
            + "    Min 1 uppercase letter."
            + "    Min 1 lowercase letter."
            + "    Min 1 special character."
            + "    Min 1 number."
            + "    Min 8 characters.")
	private String password;
    private Date created_on;
    private String created_by;
    private Date modified_on;
    private String modified_by;
    @NotNull(message = "Pincode must not be null or empty")
    @Range(min = 100000L, max = 999999L , message = "Pincode should be 6 digits and should not start with zero.")
    private long pincode;
    @Column(nullable=false,columnDefinition="varchar(25) default 'y'")
    private String Status="y";
    @NotEmpty(message = "Pancard number must not be null or empty")
    @Pattern(regexp = "^[A-Z]{5}[0-9]{4}[A-Z]{1}", message = "Pancard number name must be in capital case .")
    private String pancard;
    
	@OneToOne(mappedBy="customer",cascade=CascadeType.ALL)
	private User_Master usermaster;
	
	@OneToMany(mappedBy="customer",cascade=CascadeType.ALL)
	@JsonManagedReference
	private List<Transaction_Details> transaction_details;
	
	@OneToMany(mappedBy="customer",cascade=CascadeType.ALL)
	private List<Account_Details> account_details;

	public long getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(long customer_id) {
		this.customer_id = customer_id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getPhone_no() {
		return phone_no;
	}

	public void setPhone_no(long phone_no) {
		this.phone_no = phone_no;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getCreated_on() {
		return created_on;
	}

	public void setCreated_on(Date created_on) {
		this.created_on = created_on;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public Date getModified_on() {
		return modified_on;
	}

	public void setModified_on(Date modified_on) {
		this.modified_on = modified_on;
	}

	public String getModified_by() {
		return modified_by;
	}

	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}

	public User_Master getUsermaster() {
		return usermaster;
	}

	public void setUsermaster(User_Master usermaster) {
		this.usermaster = usermaster;
	}

	public List<Transaction_Details> getTransaction_details() {
		return transaction_details;
	}

	public void setTransaction_details(List<Transaction_Details> transaction_details) {
		this.transaction_details = transaction_details;
	}

	public List<Account_Details> getAccount_details() {
		return account_details;
	}

	public void setAccount_details(List<Account_Details> account_details) {
		this.account_details = account_details;
	}

	
	
	public Customer(long customer_id,String fname, String lname, Date dob, String email,String address, long phone_no,String password,
			Date created_on, String created_by, Date modified_on, String modified_by, long pincode, String status,
			String pancard, User_Master usermaster, List<Transaction_Details> transaction_details,
			List<Account_Details> account_details) {
		super();
		this.customer_id = customer_id;
		this.fname = fname;
		this.lname = lname;
		this.dob = dob;
		this.email = email;
		this.address = address;
		this.phone_no = phone_no;
		this.password = password;
		this.created_on = created_on;
		this.created_by = created_by;
		this.modified_on = modified_on;
		this.modified_by = modified_by;
		this.pincode = pincode;
		Status = status;
		this.pancard = pancard;
		this.usermaster = usermaster;
		this.transaction_details = transaction_details;
		this.account_details = account_details;
	}



	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public long getPincode() {
		return pincode;
	}

	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	




	public String getPancard() {
		return pancard;
	}

	public void setPancard(String pancard) {
		this.pancard = pancard;
	}

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	
	

}
