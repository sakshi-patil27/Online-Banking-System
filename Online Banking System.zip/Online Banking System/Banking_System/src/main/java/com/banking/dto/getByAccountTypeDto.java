package com.banking.dto;

public class getByAccountTypeDto {
	private long customer_id;
	private String accounttype;
	public long getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(long customer_id) {
		this.customer_id = customer_id;
	}
	public String getAccounttype() {
		return accounttype;
	}
	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}
	public getByAccountTypeDto(long customer_id, String accounttype) {
		super();
		this.customer_id = customer_id;
		this.accounttype = accounttype;
	}
	public getByAccountTypeDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}