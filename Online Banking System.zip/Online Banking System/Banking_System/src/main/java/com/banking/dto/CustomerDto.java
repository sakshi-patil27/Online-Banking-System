package com.banking.dto;

import java.sql.Date;
import java.util.List;

import com.banking.entity.Account_Details;

public class CustomerDto {
    private long customer_id;
    private String fname;
    private String lname;
    private Date dob;
    private String email;
    private String address;
    private long phone_no;
    private List<Account_DetailsDto> account_details;
    private long pincode;
   private String pancard;
   
    public String getPancard() {
	return pancard;
}
public void setPancard(String pancard) {
	this.pancard = pancard;
}
	public List<Account_DetailsDto> getAccount_details() {
		return account_details;
	}
	public void setAccount_details(List<Account_DetailsDto> account_details) {
		this.account_details = account_details;
	}
	public long getPincode() {
		return pincode;
	}
	public void setPincode(long pincode) {
		this.pincode = pincode;
	}
	public CustomerDto() {
        super();
        // TODO Auto-generated constructor stub
    }
    public CustomerDto(long customer_id, String fname, String lname, Date dob, String email, String address,
            long phone_no, List<Account_DetailsDto> accountDetails) {
        super();
        this.customer_id = customer_id;
        this.fname = fname;
        this.lname = lname;
        this.dob = dob;
        this.email = email;
        this.address = address;
        this.phone_no = phone_no;
        this.account_details = account_details;
    }
   
    public long getCustomer_id() {
        return customer_id;
    }
    public void setCustomer_id(long customer_id) {
        this.customer_id = customer_id;
    }
    public String getFname() {
        return fname;
    }
    public void setFname(String fname) {
        this.fname = fname;
    }
    public String getLname() {
        return lname;
    }
    public void setLname(String lname) {
        this.lname = lname;
    }
    public Date getDob() {
        return dob;
    }
    public void setDob(Date dob) {
        this.dob = dob;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public long getPhone_no() {
        return phone_no;
    }
    public void setPhone_no(long phone_no) {
        this.phone_no = phone_no;
    }
   
    public List<Account_DetailsDto> getAccountDetails() {
        return account_details;
    }
    public void setAccountDetails(List<Account_DetailsDto> account_details) {
        this.account_details = account_details;
    }
    @Override
    public String toString() {
        return "CustomerDto [customer_id=" + customer_id + ", fname=" + fname + ", lname=" + lname + ", dob=" + dob
                + ", email=" + email + ", address=" + address + ", phone_no=" + phone_no + ", accountDetails="
                + account_details + "]";
    }
   
   
   
}



