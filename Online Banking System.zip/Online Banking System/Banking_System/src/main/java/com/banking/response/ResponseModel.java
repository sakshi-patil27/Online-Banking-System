package com.banking.response;

public class ResponseModel {
private String message;
private String status;
public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public ResponseModel(String message, String status) {
	super();
	this.message = message;
	this.status = status;
}
public ResponseModel() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "ResponseModel [message=" + message + ", status=" + status + "]";
}

}
